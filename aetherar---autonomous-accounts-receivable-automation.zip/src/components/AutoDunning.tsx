import React, { useState } from 'react';
import { DunningQueueItem, DunningTierConfig, Invoice } from '../types';

interface AutoDunningProps {
  dunningTiers: DunningTierConfig[];
  queueItems: DunningQueueItem[];
  invoices: Invoice[];
  onDispatchQueueItem: (itemId: string) => void;
  onDispatchAll: () => void;
  onOpenDraftModal: (item: DunningQueueItem) => void;
  onToggleTierAutoSend: (tierNumber: number) => void;
  onPauseItem: (itemId: string) => void;
}

export const AutoDunning: React.FC<AutoDunningProps> = ({
  dunningTiers,
  queueItems,
  invoices,
  onDispatchQueueItem,
  onDispatchAll,
  onOpenDraftModal,
  onToggleTierAutoSend,
  onPauseItem,
}) => {
  const [activeTab, setActiveTab] = useState<'queue' | 'tiers' | 'disputes'>('queue');
  const [dispatchingAll, setDispatchingAll] = useState(false);

  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      maximumFractionDigits: 0,
    }).format(val);
  };

  const handleBatchDispatch = () => {
    setDispatchingAll(true);
    setTimeout(() => {
      onDispatchAll();
      setDispatchingAll(false);
    }, 1000);
  };

  // Disputed invoices
  const disputedInvoices = invoices.filter((inv) => inv.disputeReason && inv.status !== 'PAID');

  const pendingCount = queueItems.filter((i) => i.status === 'PENDING_DISPATCH').length;

  return (
    <div className="space-y-8 max-w-7xl mx-auto px-4 sm:px-6 py-6">
      {/* Page Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white">Auto-Dunning & Communication Cadence</h1>
          <div className="flex items-center gap-2 text-xs text-slate-400 mt-1">
            <span>Automated Multi-Tier Recovery</span>
            <span aria-hidden="true">·</span>
            <span>AI Dynamic Tone Adaptation</span>
            <span aria-hidden="true">·</span>
            <span>Dispute Guard Active</span>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={handleBatchDispatch}
            disabled={pendingCount === 0 || dispatchingAll}
            className="px-4 py-1.5 text-xs font-semibold text-slate-950 bg-cyan-400 rounded hover:bg-cyan-300 transition-colors disabled:opacity-50 whitespace-nowrap shadow-sm"
          >
            {dispatchingAll ? 'Dispatching Batch...' : `Dispatch Scheduled Batch (${pendingCount})`}
          </button>
        </div>
      </div>

      {/* Cadence Pipeline Visual Ribbon */}
      <div className="p-5 bg-slate-900/70 border border-slate-800 rounded space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-base font-semibold text-white">Multi-Tier Escalation Architecture</h2>
          <span className="text-xs text-slate-400">Automatic progression based on payment maturity</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
          {dunningTiers.map((tier) => (
            <div
              key={tier.tier}
              className={`p-3 border rounded transition-colors ${
                tier.tier === 0
                  ? 'border-emerald-800/60 bg-emerald-950/20'
                  : tier.tier === 1
                  ? 'border-cyan-800/60 bg-cyan-950/20'
                  : tier.tier === 2
                  ? 'border-amber-800/60 bg-amber-950/20'
                  : tier.tier === 3
                  ? 'border-orange-800/60 bg-orange-950/20'
                  : 'border-rose-800/60 bg-rose-950/20'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono font-bold text-slate-200">Tier {tier.tier}</span>
                <span className="text-[11px] font-mono text-slate-400">
                  {tier.triggerDays < 0 ? `${tier.triggerDays}d` : `+${tier.triggerDays}d`}
                </span>
              </div>
              <div className="text-xs font-semibold text-white mt-1 line-clamp-1">{tier.name}</div>
              <div className="text-[11px] text-slate-400 mt-1 line-clamp-2 leading-tight">
                {tier.description}
              </div>
              <div className="mt-3 pt-2 border-t border-slate-800 flex items-center justify-between text-xs">
                <span className="font-mono text-white tabular-nums">{tier.activeInvoiceCount} Active</span>
                <button
                  onClick={() => onToggleTierAutoSend(tier.tier)}
                  className={`text-[10px] font-mono uppercase px-1.5 py-0.5 rounded ${
                    tier.autoSend ? 'bg-emerald-900/60 text-emerald-300' : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  {tier.autoSend ? 'Auto-Pilot' : 'Manual Review'}
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Tabs: Queue vs Configuration vs Disputes */}
      <div className="space-y-4">
        <div className="flex items-center gap-3 border-b border-slate-800 pb-2">
          <button
            onClick={() => setActiveTab('queue')}
            className={`text-xs font-medium pb-2 border-b-2 -mb-2 transition-colors ${
              activeTab === 'queue'
                ? 'border-cyan-400 text-cyan-400 font-semibold'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            Today's Scheduled Dispatch Queue ({pendingCount})
          </button>
          <button
            onClick={() => setActiveTab('disputes')}
            className={`text-xs font-medium pb-2 border-b-2 -mb-2 transition-colors ${
              activeTab === 'disputes'
                ? 'border-cyan-400 text-cyan-400 font-semibold'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            Dispute Guard & Auto-Holds ({disputedInvoices.length})
          </button>
          <button
            onClick={() => setActiveTab('tiers')}
            className={`text-xs font-medium pb-2 border-b-2 -mb-2 transition-colors ${
              activeTab === 'tiers'
                ? 'border-cyan-400 text-cyan-400 font-semibold'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            Cadence Configuration
          </button>
        </div>

        {/* Tab 1: Live Dispatch Queue */}
        {activeTab === 'queue' && (
          <div className="space-y-4">
            {queueItems.length === 0 ? (
              <div className="p-8 text-center text-slate-400 bg-slate-900/70 border border-slate-800 rounded">
                All scheduled dunning communications have been dispatched for today.
              </div>
            ) : (
              queueItems.map((item) => {
                const isPending = item.status === 'PENDING_DISPATCH';
                return (
                  <div
                    key={item.id}
                    className={`p-4 bg-slate-900/70 border rounded transition-colors ${
                      isPending ? 'border-slate-800 hover:border-slate-700' : 'border-slate-800/40 opacity-70'
                    }`}
                  >
                    <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                      {/* Left: Invoice & Customer Context */}
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-bold text-white">{item.customerName}</span>
                          <span className="text-xs font-mono text-cyan-400">{item.invoiceNumber}</span>
                          <span className="text-xs text-slate-400">·</span>
                          <span className="text-xs font-mono text-slate-400">Tier {item.tier}: {item.tierName}</span>
                        </div>
                        <div className="flex items-center gap-2 text-xs text-slate-400">
                          <span>Recipient: {item.contactPerson} ({item.contactEmail})</span>
                          <span aria-hidden="true">·</span>
                          <span className="font-mono text-rose-400">+{item.daysOverdue} days past due</span>
                          <span aria-hidden="true">·</span>
                          <span className="font-mono text-white font-semibold tabular-nums">
                            {formatCurrency(item.amount)}
                          </span>
                        </div>
                        {item.keyTacticalAdvice && (
                          <div className="text-xs text-amber-300/90 pt-1 flex items-center gap-1.5">
                            <span className="text-[10px] font-mono uppercase bg-amber-950/80 px-1.5 py-0.5 border border-amber-800/60 rounded">
                              AI Strategy
                            </span>
                            <span>{item.keyTacticalAdvice}</span>
                          </div>
                        )}
                      </div>

                      {/* Right: Actions */}
                      <div className="flex items-center gap-2 shrink-0">
                        {isPending ? (
                          <>
                            <button
                              onClick={() => onOpenDraftModal(item)}
                              className="px-3 py-1.5 text-xs font-medium text-slate-200 bg-slate-800 hover:bg-slate-700 rounded transition-colors"
                            >
                              Review & AI Draft
                            </button>
                            <button
                              onClick={() => onPauseItem(item.id)}
                              className="px-2.5 py-1.5 text-xs text-slate-400 hover:text-white bg-slate-900 border border-slate-800 rounded transition-colors"
                            >
                              Pause
                            </button>
                            <button
                              onClick={() => onDispatchQueueItem(item.id)}
                              className="px-3.5 py-1.5 text-xs font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded transition-colors"
                            >
                              Dispatch Now
                            </button>
                          </>
                        ) : (
                          <div className="text-xs font-mono text-emerald-400 bg-emerald-950/40 px-2 py-1 border border-emerald-800/40 rounded">
                            ✓ Dispatched via {item.channel}
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Collapsed Email Subject Preview */}
                    <div className="mt-3 pt-3 border-t border-slate-800/80 text-xs">
                      <div className="text-slate-300">
                        <span className="text-slate-500 font-mono">Subject: </span>
                        {item.generatedSubject}
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        )}

        {/* Tab 2: Dispute Guard & Auto-Holds */}
        {activeTab === 'disputes' && (
          <div className="space-y-4">
            <div className="p-4 bg-amber-950/20 border border-amber-800/40 rounded text-xs text-amber-200">
              <span className="font-semibold">Automated Dispute Guard Active:</span> Any invoice marked with a customer billing dispute is immediately withheld from automated dunning cadences to protect client relationships during investigation.
            </div>

            <div className="divide-y divide-slate-800 border border-slate-800 rounded bg-slate-900/50">
              {disputedInvoices.map((inv) => (
                <div key={inv.id} className="p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-bold text-white">{inv.customerName}</span>
                      <span className="text-xs font-mono text-slate-400">{inv.invoiceNumber}</span>
                      <span className="text-xs font-mono text-rose-400 font-semibold tabular-nums">
                        {formatCurrency(inv.balance)}
                      </span>
                    </div>
                    <div className="text-xs text-amber-300 mt-1">
                      <span className="font-semibold">Dispute Cause:</span> {inv.disputeReason}
                    </div>
                    <div className="text-xs text-slate-400 mt-1">
                      Contact: {inv.contactPerson} ({inv.contactEmail}) · Due Date: {inv.dueDate}
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <span className="text-xs font-mono text-amber-400 bg-amber-950/40 border border-amber-800/40 px-2 py-1 rounded">
                      Dunning Paused
                    </span>
                    <button
                      onClick={() => alert(`Opening Dispute Investigation Workbench for ${inv.invoiceNumber}`)}
                      className="px-3 py-1.5 text-xs text-slate-200 bg-slate-800 hover:bg-slate-700 rounded transition-colors"
                    >
                      Resolve Dispute
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Tab 3: Cadence Configuration */}
        {activeTab === 'tiers' && (
          <div className="p-5 bg-slate-900/70 border border-slate-800 rounded space-y-4">
            <h3 className="text-sm font-semibold text-white">Cadence Trigger Rules & Auto-Pilot Policies</h3>
            <div className="space-y-3">
              {dunningTiers.map((tier) => (
                <div key={tier.tier} className="p-4 border border-slate-800 rounded bg-slate-950/40 flex items-center justify-between">
                  <div className="space-y-1">
                    <div className="text-sm font-semibold text-white">
                      Tier {tier.tier}: {tier.name}
                    </div>
                    <div className="text-xs text-slate-400">
                      Trigger: {tier.triggerDays < 0 ? `${Math.abs(tier.triggerDays)} days before due date` : `${tier.triggerDays} days after due date`} · Channel: {tier.channel}
                    </div>
                    <div className="text-xs text-slate-400">
                      Default Tone: {tier.defaultTone}
                    </div>
                  </div>

                  <button
                    onClick={() => onToggleTierAutoSend(tier.tier)}
                    className={`px-3 py-1.5 text-xs font-medium rounded transition-colors ${
                      tier.autoSend
                        ? 'bg-emerald-600 text-white'
                        : 'bg-slate-800 text-slate-300 hover:text-white'
                    }`}
                  >
                    {tier.autoSend ? 'Auto-Dispatch Enabled' : 'Requires Approval'}
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
