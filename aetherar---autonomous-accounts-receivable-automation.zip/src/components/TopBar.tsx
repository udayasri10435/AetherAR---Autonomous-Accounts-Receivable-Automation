import React from 'react';

interface TopBarProps {
  activeTab: 'aging' | 'dunning' | 'collections' | 'cashapp' | 'roi';
  setActiveTab: (tab: 'aging' | 'dunning' | 'collections' | 'cashapp' | 'roi') => void;
  onOpenNewInvoiceModal: () => void;
  onTriggerQuickSync: () => void;
  isSyncing: boolean;
  unappliedCount: number;
  dunningQueueCount: number;
}

export const TopBar: React.FC<TopBarProps> = ({
  activeTab,
  setActiveTab,
  onOpenNewInvoiceModal,
  onTriggerQuickSync,
  isSyncing,
  unappliedCount,
  dunningQueueCount,
}) => {
  return (
    <header className="sticky top-0 z-30 flex items-center justify-between px-6 py-3.5 bg-slate-950/90 backdrop-blur-md border-b border-slate-800/80">
      {/* Zone 1: Single text element Brand Wordmark */}
      <a
        href="#"
        onClick={(e) => {
          e.preventDefault();
          setActiveTab('aging');
        }}
        className="text-lg font-bold tracking-tight text-white hover:text-cyan-400 transition-colors"
      >
        AetherAR
      </a>

      {/* Zone 2: 4-6 Clean text navigation links (single-line, hover underlines) */}
      <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-slate-300">
        <button
          onClick={() => setActiveTab('aging')}
          className={`whitespace-nowrap transition-colors relative py-1 ${
            activeTab === 'aging'
              ? 'text-cyan-400 font-semibold'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          Aging Dashboard
          {activeTab === 'aging' && (
            <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-cyan-400 rounded-full" />
          )}
        </button>

        <button
          onClick={() => setActiveTab('dunning')}
          className={`whitespace-nowrap transition-colors relative py-1 flex items-center gap-1.5 ${
            activeTab === 'dunning'
              ? 'text-cyan-400 font-semibold'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          Auto-Dunning
          {dunningQueueCount > 0 && (
            <span className="text-xs font-mono text-cyan-400">({dunningQueueCount})</span>
          )}
          {activeTab === 'dunning' && (
            <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-cyan-400 rounded-full" />
          )}
        </button>

        <button
          onClick={() => setActiveTab('collections')}
          className={`whitespace-nowrap transition-colors relative py-1 ${
            activeTab === 'collections'
              ? 'text-cyan-400 font-semibold'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          Smart Collections
          {activeTab === 'collections' && (
            <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-cyan-400 rounded-full" />
          )}
        </button>

        <button
          onClick={() => setActiveTab('cashapp')}
          className={`whitespace-nowrap transition-colors relative py-1 flex items-center gap-1.5 ${
            activeTab === 'cashapp'
              ? 'text-cyan-400 font-semibold'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          AI Cash Application
          {unappliedCount > 0 && (
            <span className="text-xs font-mono text-emerald-400">({unappliedCount})</span>
          )}
          {activeTab === 'cashapp' && (
            <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-cyan-400 rounded-full" />
          )}
        </button>

        <button
          onClick={() => setActiveTab('roi')}
          className={`whitespace-nowrap transition-colors relative py-1 ${
            activeTab === 'roi'
              ? 'text-cyan-400 font-semibold'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          CFO ROI Simulator
          {activeTab === 'roi' && (
            <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-cyan-400 rounded-full" />
          )}
        </button>
      </nav>

      {/* Zone 3: 1-2 Primary actions */}
      <div className="flex items-center gap-3">
        <button
          onClick={onTriggerQuickSync}
          disabled={isSyncing}
          className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-300 bg-slate-900 border border-slate-700/80 rounded hover:bg-slate-800 hover:text-white transition-colors disabled:opacity-50"
        >
          <span className={`inline-block w-2 h-2 rounded-full ${isSyncing ? 'bg-amber-400 animate-ping' : 'bg-emerald-400'}`} />
          {isSyncing ? 'Syncing ERP...' : 'ERP Live Sync'}
        </button>

        <button
          onClick={onOpenNewInvoiceModal}
          className="px-3.5 py-1.5 text-xs font-semibold text-slate-950 bg-cyan-400 rounded hover:bg-cyan-300 transition-colors whitespace-nowrap shadow-sm"
        >
          + Record Invoice
        </button>
      </div>
    </header>
  );
};
