import React from 'react';
import { Invoice } from '../types';

interface InvoiceDetailModalProps {
  invoice: Invoice | null;
  onClose: () => void;
  onMarkPaid: (invoiceId: string) => void;
  onTriggerDunning: (invoice: Invoice) => void;
  onLogDispute: (invoiceId: string, reason: string) => void;
}

export const InvoiceDetailModal: React.FC<InvoiceDetailModalProps> = ({
  invoice,
  onClose,
  onMarkPaid,
  onTriggerDunning,
  onLogDispute,
}) => {
  if (!invoice) return null;

  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      maximumFractionDigits: 0,
    }).format(val);
  };

  const handleDisputePrompt = () => {
    const reason = window.prompt(
      'Enter customer billing dispute cause (e.g. SLA rebate, missing PO, tax exemption):',
      'Customer requested billing reconciliation for services rendered.'
    );
    if (reason) {
      onLogDispute(invoice.id, reason);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
      <div className="w-full max-w-2xl bg-slate-900 border border-slate-800 rounded shadow-2xl overflow-hidden">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800">
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-bold text-white">{invoice.invoiceNumber}</h2>
              <span className="text-xs font-mono text-cyan-400 font-semibold">Tier {invoice.dunningTier}</span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">{invoice.customerName} · PO: {invoice.poNumber}</p>
          </div>

          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white text-lg p-1"
          >
            ✕
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 space-y-6 text-xs text-slate-300">
          {/* Top Line Summary Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 p-4 bg-slate-950/60 border border-slate-800 rounded">
            <div>
              <span className="text-slate-500 font-medium">Invoice Balance</span>
              <div className="text-lg font-bold font-mono text-white mt-1 tabular-nums">
                {formatCurrency(invoice.balance)}
              </div>
            </div>

            <div>
              <span className="text-slate-500 font-medium">Original Amount</span>
              <div className="text-base font-semibold font-mono text-slate-300 mt-1 tabular-nums">
                {formatCurrency(invoice.amount)}
              </div>
            </div>

            <div>
              <span className="text-slate-500 font-medium">Maturity Status</span>
              <div className="mt-1 font-mono">
                {invoice.daysOverdue > 0 ? (
                  <span className="text-rose-400 font-bold">+{invoice.daysOverdue} Days Overdue</span>
                ) : (
                  <span className="text-emerald-400 font-bold">Current</span>
                )}
              </div>
            </div>

            <div>
              <span className="text-slate-500 font-medium">Payment Terms</span>
              <div className="text-sm font-semibold text-slate-200 mt-1 font-mono">
                {invoice.paymentTerms}
              </div>
            </div>
          </div>

          {/* Customer & Billing Metadata */}
          <div className="space-y-2 border-t border-slate-800 pt-4">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-400">
              Billing & Contact Specifications
            </h3>
            <div className="grid grid-cols-2 gap-4 text-xs">
              <div>
                <span className="text-slate-500">AP Contact:</span>{' '}
                <span className="text-white font-medium">{invoice.contactPerson}</span>
              </div>
              <div>
                <span className="text-slate-500">Direct Email:</span>{' '}
                <span className="text-cyan-400">{invoice.contactEmail}</span>
              </div>
              <div>
                <span className="text-slate-500">Issue Date:</span>{' '}
                <span className="font-mono text-slate-300">{invoice.issueDate}</span>
              </div>
              <div>
                <span className="text-slate-500">Due Date:</span>{' '}
                <span className="font-mono text-slate-300">{invoice.dueDate}</span>
              </div>
            </div>
          </div>

          {/* Active Dispute Information if present */}
          {invoice.disputeReason && (
            <div className="p-3 bg-amber-950/30 border border-amber-800/60 rounded space-y-1">
              <span className="font-semibold text-amber-300">Active Dispute Note:</span>
              <p className="text-slate-300">{invoice.disputeReason}</p>
              <div className="text-[11px] text-amber-400 font-mono">
                Auto-Dunning Hold: ACTIVE (No automated notifications sent)
              </div>
            </div>
          )}

          {/* Active Promise to Pay if present */}
          {invoice.promiseToPayDate && (
            <div className="p-3 bg-cyan-950/30 border border-cyan-800/60 rounded space-y-1">
              <span className="font-semibold text-cyan-300">Recorded Promise to Pay:</span>
              <div className="flex items-center gap-3 font-mono text-slate-200">
                <span>Committed: {formatCurrency(invoice.promiseToPayAmount || invoice.balance)}</span>
                <span>Target Date: {invoice.promiseToPayDate}</span>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer Actions */}
        <div className="flex items-center justify-between px-6 py-4 bg-slate-950 border-t border-slate-800">
          <div className="flex items-center gap-2">
            {!invoice.disputeReason && (
              <button
                onClick={handleDisputePrompt}
                className="px-3 py-1.5 text-xs text-amber-300 hover:text-amber-200 bg-amber-950/40 border border-amber-800/60 rounded transition-colors"
              >
                Log Dispute / Hold
              </button>
            )}
            <button
              onClick={() => onMarkPaid(invoice.id)}
              className="px-3 py-1.5 text-xs text-emerald-300 hover:text-emerald-200 bg-emerald-950/40 border border-emerald-800/60 rounded transition-colors"
            >
              Mark Full Paid
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                onClose();
                onTriggerDunning(invoice);
              }}
              className="px-4 py-1.5 text-xs font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded transition-colors"
            >
              Draft Dunning Communication →
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
