import React, { useState } from 'react';
import { DunningQueueItem } from '../types';

interface DunningEmailModalProps {
  item: DunningQueueItem | null;
  onClose: () => void;
  onSend: (itemId: string, updatedSubject: string, updatedBody: string) => void;
}

export const DunningEmailModal: React.FC<DunningEmailModalProps> = ({
  item,
  onClose,
  onSend,
}) => {
  if (!item) return null;

  const [tone, setTone] = useState<string>(item.aiSuggestedTone || 'Structured Enterprise');
  const [subject, setSubject] = useState<string>(item.generatedSubject);
  const [body, setBody] = useState<string>(item.generatedBody);
  const [tacticalAdvice, setTacticalAdvice] = useState<string>(item.keyTacticalAdvice || '');
  const [isGenerating, setIsGenerating] = useState(false);
  const [isSending, setIsSending] = useState(false);

  const handleRegenerateWithAI = async (selectedTone: string) => {
    setTone(selectedTone);
    setIsGenerating(true);

    try {
      const response = await fetch('/api/gemini/dunning', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          customerName: item.customerName,
          contactPerson: item.contactPerson,
          invoiceNumber: item.invoiceNumber,
          amount: item.amount,
          daysOverdue: item.daysOverdue,
          tier: item.tier,
          tierName: item.tierName,
          tone: selectedTone,
          pastPaymentHabits: 'Historical average DSO 42 days, responds reliably to portal links.',
        }),
      });

      const data = await response.json();
      if (data.subject && data.body) {
        setSubject(data.subject);
        setBody(data.body);
        if (data.keyAdvice) setTacticalAdvice(data.keyAdvice);
      } else {
        // Fallback tone switch
        applyLocalToneFallback(selectedTone);
      }
    } catch (err) {
      console.warn('Using intelligent fallback for dunning drafting:', err);
      applyLocalToneFallback(selectedTone);
    } finally {
      setIsGenerating(false);
    }
  };

  const applyLocalToneFallback = (selectedTone: string) => {
    if (selectedTone === 'Executive Notice' || selectedTone === 'Executive Escalation') {
      setSubject(`EXECUTIVE ATTENTION: Overdue Balance - ${item.invoiceNumber} ($${item.amount.toLocaleString()})`);
      setBody(`Dear ${item.contactPerson},\n\nI am contacting you from executive finance regarding outstanding invoice ${item.invoiceNumber} for $${item.amount.toLocaleString()}, now ${item.daysOverdue} days overdue.\n\nTo ensure uninterrupted services and maintain your credit tier, please remit payment via our secure portal today: https://pay.aetherar.internal/inv/${item.invoiceNumber}\n\nSincerely,\nOffice of the CFO`);
      setTacticalAdvice('CFO-to-CFO escalation tone; prioritize direct electronic payment link.');
    } else if (selectedTone === 'Diplomatic') {
      setSubject(`Courtesy Reminder: Invoice ${item.invoiceNumber} - ${item.customerName}`);
      setBody(`Hi ${item.contactPerson},\n\nWe hope this week is going well. We wanted to share a friendly reminder regarding invoice ${item.invoiceNumber} for $${item.amount.toLocaleString()}.\n\nPlease let us know if you need another copy of the invoice or PO confirmation.\n\nDirect settlement portal: https://pay.aetherar.internal/inv/${item.invoiceNumber}\n\nWarm regards,\nAetherAR Billing Team`);
      setTacticalAdvice('Preserve relationship; assume delay is administrative.');
    } else {
      setSubject(`Overdue Notice: Invoice ${item.invoiceNumber} ($${item.amount.toLocaleString()})`);
      setBody(`Dear ${item.contactPerson},\n\nThis is a notification that invoice ${item.invoiceNumber} for $${item.amount.toLocaleString()} is currently past due by ${item.daysOverdue} days.\n\nPlease process this in your upcoming payment run or settle via ACH: https://pay.aetherar.internal/inv/${item.invoiceNumber}\n\nThank you,\nCredit Operations`);
      setTacticalAdvice('Clear deadline with attached billing documentation.');
    }
  };

  const handleSend = () => {
    setIsSending(true);
    setTimeout(() => {
      onSend(item.id, subject, body);
      setIsSending(false);
      onClose();
    }, 600);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
      <div className="w-full max-w-3xl bg-slate-900 border border-slate-800 rounded shadow-2xl overflow-hidden">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800">
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-bold text-white">Review & AI Customize Dunning Notice</h2>
              <span className="text-xs font-mono text-cyan-400 font-semibold">Tier {item.tier}</span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Recipient: {item.contactPerson} ({item.contactEmail}) · {item.customerName}
            </p>
          </div>

          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white text-lg p-1"
          >
            ✕
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-5 text-xs text-slate-300">
          {/* Tone Selector */}
          <div className="space-y-1.5">
            <span className="font-semibold text-slate-300 uppercase tracking-wider text-[11px]">
              AI Tone & Strategy Selection
            </span>
            <div className="flex flex-wrap items-center gap-2">
              {['Diplomatic', 'Structured Enterprise', 'Firm Collections', 'Executive Notice'].map((t) => (
                <button
                  key={t}
                  onClick={() => handleRegenerateWithAI(t)}
                  disabled={isGenerating}
                  className={`px-3 py-1.5 rounded transition-colors text-xs font-medium ${
                    tone === t
                      ? 'bg-cyan-400 text-slate-950 font-bold'
                      : 'bg-slate-800 text-slate-300 hover:text-white'
                  }`}
                >
                  {t}
                </button>
              ))}
              {isGenerating && <span className="text-cyan-400 font-mono animate-pulse">Drafting with Gemini AI...</span>}
            </div>
          </div>

          {/* AI Strategy Advice Card */}
          {tacticalAdvice && (
            <div className="p-3 bg-amber-950/20 border border-amber-800/40 rounded flex items-center gap-2 text-amber-200">
              <span className="text-[10px] font-mono uppercase bg-amber-900/60 px-1.5 py-0.5 rounded">
                Tactical Insight
              </span>
              <span>{tacticalAdvice}</span>
            </div>
          )}

          {/* Subject Field */}
          <div className="space-y-1">
            <label className="text-slate-400 font-medium">Email Subject Line</label>
            <input
              type="text"
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded text-white font-mono text-xs focus:outline-none focus:border-cyan-500"
            />
          </div>

          {/* Body Field */}
          <div className="space-y-1">
            <label className="text-slate-400 font-medium">Communication Body</label>
            <textarea
              rows={8}
              value={body}
              onChange={(e) => setBody(e.target.value)}
              className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded text-slate-200 font-sans text-xs leading-relaxed focus:outline-none focus:border-cyan-500 font-mono"
            />
          </div>
        </div>

        {/* Modal Footer */}
        <div className="flex items-center justify-between px-6 py-4 bg-slate-950 border-t border-slate-800">
          <div className="text-xs text-slate-500">
            Channel: Email + Verified Self-Serve Payment Link
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-3 py-1.5 text-xs text-slate-400 hover:text-white"
            >
              Cancel
            </button>
            <button
              onClick={handleSend}
              disabled={isSending}
              className="px-4 py-1.5 text-xs font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded transition-colors disabled:opacity-50"
            >
              {isSending ? 'Transmitting Notice...' : 'Send Communication Now'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
