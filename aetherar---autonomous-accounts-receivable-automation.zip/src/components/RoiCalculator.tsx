import React, { useState, useMemo } from 'react';

export const RoiCalculator: React.FC = () => {
  const [annualRevenue, setAnnualRevenue] = useState<number>(48000000);
  const [currentDSO, setCurrentDSO] = useState<number>(46.0);
  const [targetDSO, setTargetDSO] = useState<number>(39.5);
  const [costOfCapital, setCostOfCapital] = useState<number>(8.5); // %
  const [badDebtRate, setBadDebtRate] = useState<number>(1.2); // %
  const [badDebtReduction, setBadDebtReduction] = useState<number>(45); // %
  const [copiedMemo, setCopiedMemo] = useState(false);

  // DSO Reduction in Days
  const dsoDaysSaved = useMemo(() => {
    return Math.max(0, Number((currentDSO - targetDSO).toFixed(1)));
  }, [currentDSO, targetDSO]);

  // Daily Sales Calculation
  const dailySales = useMemo(() => {
    return annualRevenue / 365;
  }, [annualRevenue]);

  // 1. One-time Cash Working Capital Released
  const workingCapitalReleased = useMemo(() => {
    return dailySales * dsoDaysSaved;
  }, [dailySales, dsoDaysSaved]);

  // 2. Annual Interest / Cost of Capital Carry Savings
  const annualInterestSaved = useMemo(() => {
    return workingCapitalReleased * (costOfCapital / 100);
  }, [workingCapitalReleased, costOfCapital]);

  // 3. Bad Debt Loss Avoided
  const badDebtLossAvoided = useMemo(() => {
    const totalBadDebtCurrent = annualRevenue * (badDebtRate / 100);
    return totalBadDebtCurrent * (badDebtReduction / 100);
  }, [annualRevenue, badDebtRate, badDebtReduction]);

  // 4. Total Annual Recurring Bottom-Line Impact
  const totalAnnualImpact = useMemo(() => {
    return annualInterestSaved + badDebtLossAvoided;
  }, [annualInterestSaved, badDebtLossAvoided]);

  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      maximumFractionDigits: 0,
    }).format(val);
  };

  const applyPreset = (days: number) => {
    setTargetDSO(Number(Math.max(15, currentDSO - days).toFixed(1)));
  };

  const boardMemoText = `EXECUTIVE TREASURY BRIEFING: ACCOUNTS RECEIVABLE AUTOMATION ROI
=============================================================
Prepared for: Chief Financial Officer & Executive Committee
Analysis Date: ${new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
Basis: Current vs. Post-Automation AR Acceleration

1. CORE WORKING CAPITAL IMPACT:
-------------------------------------------------------------
- Current Portfolio DSO: ${currentDSO} Days
- Target Automated DSO: ${targetDSO} Days
- Net DSO Reduction: ${dsoDaysSaved} Days
- Annual Credit Revenue: ${formatCurrency(annualRevenue)}
- DAILY LIQUIDITY VELOCITY: ${formatCurrency(dailySales)} / day

IMMEDIATE BALANCE SHEET CASH LIBERATED: ${formatCurrency(workingCapitalReleased)}
(Direct reduction in accounts receivable tied up in open balances)

2. ANNUAL P&L SAVINGS & VALUE CREATION:
-------------------------------------------------------------
- Weighted Cost of Capital (WACC): ${costOfCapital}%
- Annual Interest Expense Avoided: ${formatCurrency(annualInterestSaved)} / year
- Bad Debt Reduction (${badDebtReduction}% of ${badDebtRate}% base): ${formatCurrency(badDebtLossAvoided)} / year
- TOTAL RECURRING ANNUAL P&L BENEFIT: ${formatCurrency(totalAnnualImpact)} / year

3. STRATEGIC CONCLUSION:
Automating AR dunning cadences, cash application matching, and predictive collector workflows directly releases ${formatCurrency(workingCapitalReleased)} into corporate cash reserves, while returning ${formatCurrency(totalAnnualImpact)} per year in recurring interest savings and bad debt mitigation.`;

  const handleCopyMemo = () => {
    navigator.clipboard.writeText(boardMemoText);
    setCopiedMemo(true);
    setTimeout(() => setCopiedMemo(false), 2500);
  };

  return (
    <div className="space-y-8 max-w-7xl mx-auto px-4 sm:px-6 py-6">
      {/* Page Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white">CFO Working Capital & DSO Reduction ROI Simulator</h1>
          <div className="flex items-center gap-2 text-xs text-slate-400 mt-1">
            <span>Dynamic Treasury Model</span>
            <span aria-hidden="true">·</span>
            <span>Formula: ΔWorking Capital = (Annual Sales / 365) × ΔDSO</span>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={handleCopyMemo}
            className="px-3.5 py-1.5 text-xs font-semibold text-slate-950 bg-cyan-400 rounded hover:bg-cyan-300 transition-colors whitespace-nowrap"
          >
            {copiedMemo ? '✓ Board Briefing Copied' : 'Copy Boardroom Briefing'}
          </button>
        </div>
      </div>

      {/* Hero Impact Summary Display */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        <div className="p-6 bg-gradient-to-br from-slate-900 to-cyan-950/40 border border-cyan-800/60 rounded">
          <span className="text-xs font-semibold uppercase tracking-wider text-cyan-400">
            Immediate Free Cash Flow Released
          </span>
          <div className="text-3xl sm:text-4xl font-extrabold font-mono text-white mt-2 tabular-nums">
            {formatCurrency(workingCapitalReleased)}
          </div>
          <p className="text-xs text-slate-300 mt-2">
            Non-dilutive cash freed from customer balances directly into corporate bank accounts by cutting {dsoDaysSaved} days of DSO.
          </p>
        </div>

        <div className="p-6 bg-gradient-to-br from-slate-900 to-emerald-950/40 border border-emerald-800/60 rounded">
          <span className="text-xs font-semibold uppercase tracking-wider text-emerald-400">
            Annual Interest & Carrying Savings
          </span>
          <div className="text-3xl sm:text-4xl font-extrabold font-mono text-white mt-2 tabular-nums">
            {formatCurrency(annualInterestSaved)}
            <span className="text-sm font-normal text-slate-400"> / yr</span>
          </div>
          <p className="text-xs text-slate-300 mt-2">
            Direct interest expense avoided at your {costOfCapital}% weighted cost of debt and capital.
          </p>
        </div>

        <div className="p-6 bg-gradient-to-br from-slate-900 to-amber-950/40 border border-amber-800/60 rounded">
          <span className="text-xs font-semibold uppercase tracking-wider text-amber-400">
            Total Annual Bottom-Line P&L Lift
          </span>
          <div className="text-3xl sm:text-4xl font-extrabold font-mono text-white mt-2 tabular-nums">
            {formatCurrency(totalAnnualImpact)}
            <span className="text-sm font-normal text-slate-400"> / yr</span>
          </div>
          <p className="text-xs text-slate-300 mt-2">
            Combined recurring financial benefit from debt carrying savings + {formatCurrency(badDebtLossAvoided)} in avoided bad debt write-offs.
          </p>
        </div>
      </div>

      {/* Interactive Controls & Scenario Modeler */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Side: Sliders & Controls */}
        <div className="lg:col-span-7 p-6 bg-slate-900/70 border border-slate-800 rounded space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-semibold text-white">Financial Baseline Inputs</h2>
            <div className="flex items-center gap-1.5">
              <span className="text-xs text-slate-400">Presets:</span>
              <button
                onClick={() => applyPreset(3.5)}
                className="px-2 py-0.5 text-xs text-slate-300 bg-slate-800 hover:text-white rounded"
              >
                Conservative (-3.5d)
              </button>
              <button
                onClick={() => applyPreset(6.5)}
                className="px-2 py-0.5 text-xs text-cyan-300 bg-cyan-950/60 border border-cyan-800/60 rounded"
              >
                Target (-6.5d)
              </button>
              <button
                onClick={() => applyPreset(10.0)}
                className="px-2 py-0.5 text-xs text-emerald-300 bg-emerald-950/60 border border-emerald-800/60 rounded"
              >
                Aggressive (-10.0d)
              </button>
            </div>
          </div>

          {/* Slider 1: Annual Revenue */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-medium text-slate-300">Annual Credit Sales (Revenue)</span>
              <span className="font-mono text-white font-semibold tabular-nums">
                {formatCurrency(annualRevenue)}
              </span>
            </div>
            <input
              type="range"
              min={10000000}
              max={200000000}
              step={1000000}
              value={annualRevenue}
              onChange={(e) => setAnnualRevenue(Number(e.target.value))}
              className="w-full accent-cyan-400 bg-slate-800 h-1.5 rounded cursor-pointer"
            />
            <div className="flex justify-between text-[11px] text-slate-500 font-mono">
              <span>$10M</span>
              <span>Daily Sales: {formatCurrency(dailySales)}</span>
              <span>$200M</span>
            </div>
          </div>

          {/* Slider 2: Current DSO vs Target DSO */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-medium text-slate-300">Current Portfolio DSO</span>
                <span className="font-mono text-white font-semibold tabular-nums">{currentDSO} Days</span>
              </div>
              <input
                type="range"
                min={30}
                max={90}
                step={0.5}
                value={currentDSO}
                onChange={(e) => {
                  const val = Number(e.target.value);
                  setCurrentDSO(val);
                  if (targetDSO >= val) setTargetDSO(val - 1);
                }}
                className="w-full accent-cyan-400 bg-slate-800 h-1.5 rounded cursor-pointer"
              />
              <span className="text-[11px] text-slate-500">Industry avg: 45–55 days</span>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-medium text-slate-300">Target Automated DSO</span>
                <span className="font-mono text-emerald-400 font-semibold tabular-nums">{targetDSO} Days</span>
              </div>
              <input
                type="range"
                min={20}
                max={Math.max(21, currentDSO - 0.5)}
                step={0.5}
                value={targetDSO}
                onChange={(e) => setTargetDSO(Number(e.target.value))}
                className="w-full accent-emerald-400 bg-slate-800 h-1.5 rounded cursor-pointer"
              />
              <span className="text-[11px] text-slate-500 font-mono text-emerald-400">
                Δ {dsoDaysSaved} Days Reduction
              </span>
            </div>
          </div>

          {/* Slider 3: Cost of Capital (WACC) */}
          <div className="space-y-2 pt-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-medium text-slate-300">Weighted Average Cost of Capital (WACC / Revolver Rate)</span>
              <span className="font-mono text-white font-semibold tabular-nums">{costOfCapital}%</span>
            </div>
            <input
              type="range"
              min={4.0}
              max={15.0}
              step={0.25}
              value={costOfCapital}
              onChange={(e) => setCostOfCapital(Number(e.target.value))}
              className="w-full accent-cyan-400 bg-slate-800 h-1.5 rounded cursor-pointer"
            />
            <div className="flex justify-between text-[11px] text-slate-500 font-mono">
              <span>4.0%</span>
              <span>Current Federal Reserve Benchmark + Margin</span>
              <span>15.0%</span>
            </div>
          </div>

          {/* Slider 4: Bad Debt Reduction */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-medium text-slate-300">Historical Bad Debt Write-Off</span>
                <span className="font-mono text-white font-semibold tabular-nums">{badDebtRate}%</span>
              </div>
              <input
                type="range"
                min={0.2}
                max={4.0}
                step={0.1}
                value={badDebtRate}
                onChange={(e) => setBadDebtRate(Number(e.target.value))}
                className="w-full accent-cyan-400 bg-slate-800 h-1.5 rounded cursor-pointer"
              />
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-medium text-slate-300">Auto-Dunning Recovery Lift</span>
                <span className="font-mono text-emerald-400 font-semibold tabular-nums">{badDebtReduction}% Reduction</span>
              </div>
              <input
                type="range"
                min={10}
                max={75}
                step={5}
                value={badDebtReduction}
                onChange={(e) => setBadDebtReduction(Number(e.target.value))}
                className="w-full accent-emerald-400 bg-slate-800 h-1.5 rounded cursor-pointer"
              />
            </div>
          </div>
        </div>

        {/* Right Side: CFO Mathematical Breakdown & Value Chain */}
        <div className="lg:col-span-5 p-6 bg-slate-900/70 border border-slate-800 rounded flex flex-col justify-between space-y-6">
          <div>
            <h2 className="text-base font-semibold text-white">Mathematical Capital Walk</h2>
            <p className="text-xs text-slate-400 mt-1">
              Step-by-step audit trail of cash acceleration for CFO verification
            </p>

            <div className="divide-y divide-slate-800/80 text-xs mt-4">
              <div className="py-2.5 flex justify-between">
                <span className="text-slate-400">Daily Revenue Run-Rate</span>
                <span className="font-mono text-white tabular-nums">{formatCurrency(dailySales)} / day</span>
              </div>
              <div className="py-2.5 flex justify-between">
                <span className="text-slate-400">Portfolio Days Accelerated</span>
                <span className="font-mono text-cyan-400 font-semibold tabular-nums">× {dsoDaysSaved} Days</span>
              </div>
              <div className="py-2.5 flex justify-between bg-cyan-950/20 px-2 rounded">
                <span className="font-semibold text-cyan-300">= Liberated Cash Flow</span>
                <span className="font-mono text-cyan-300 font-bold tabular-nums">{formatCurrency(workingCapitalReleased)}</span>
              </div>
              <div className="py-2.5 flex justify-between">
                <span className="text-slate-400">Capital Cost Avoidance ({costOfCapital}%)</span>
                <span className="font-mono text-emerald-400 tabular-nums">+{formatCurrency(annualInterestSaved)} / yr</span>
              </div>
              <div className="py-2.5 flex justify-between">
                <span className="text-slate-400">Uncollectible Loss Mitigation</span>
                <span className="font-mono text-emerald-400 tabular-nums">+{formatCurrency(badDebtLossAvoided)} / yr</span>
              </div>
              <div className="py-3 flex justify-between bg-emerald-950/30 px-2 rounded border-t border-emerald-800/40">
                <span className="font-bold text-emerald-400">= Net Annual Value Added</span>
                <span className="font-mono text-emerald-400 font-extrabold text-sm tabular-nums">
                  {formatCurrency(totalAnnualImpact)} / yr
                </span>
              </div>
            </div>
          </div>

          <div className="p-3 bg-slate-950/80 border border-slate-800 rounded">
            <div className="text-xs font-semibold text-slate-300">Why DSO Matters to Enterprise Valuation</div>
            <p className="text-[11px] text-slate-400 mt-1 leading-relaxed">
              Every day trimmed from DSO directly lowers working capital requirements, eliminates high-interest revolving credit facility draws, and boosts Free Cash Flow (FCF) conversion for higher company valuation multiples.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
