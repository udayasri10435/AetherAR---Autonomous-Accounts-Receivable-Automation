import React, { useState } from 'react';
import { Customer, CollectorTask, Invoice } from '../types';

interface SmartCollectionsProps {
  tasks: CollectorTask[];
  customers: Customer[];
  invoices: Invoice[];
  onResolveTask: (taskId: string) => void;
  onOpenPtpModal: (task: CollectorTask) => void;
  onSendInstantPaymentLink: (invoiceNumber: string, customerEmail: string) => void;
}

export const SmartCollections: React.FC<SmartCollectionsProps> = ({
  tasks,
  customers,
  invoices,
  onResolveTask,
  onOpenPtpModal,
  onSendInstantPaymentLink,
}) => {
  const [activeView, setActiveView] = useState<'worklist' | 'ptp' | 'customers'>('worklist');
  const [filterPriority, setFilterPriority] = useState<'ALL' | 'HIGH' | 'MEDIUM' | 'LOW'>('ALL');

  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      maximumFractionDigits: 0,
    }).format(val);
  };

  const filteredTasks = tasks.filter((t) => {
    if (filterPriority !== 'ALL' && t.priority !== filterPriority) return false;
    return true;
  });

  const ptpTasks = tasks.filter((t) => t.hasPtp);

  return (
    <div className="space-y-8 max-w-7xl mx-auto px-4 sm:px-6 py-6">
      {/* Page Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white">Smart Collections & Risk-Scored Worklist</h1>
          <div className="flex items-center gap-2 text-xs text-slate-400 mt-1">
            <span>Prioritized Collection Queue</span>
            <span aria-hidden="true">·</span>
            <span>Payment Velocity Analysis</span>
            <span aria-hidden="true">·</span>
            <span>Promise-to-Pay (PTP) Tracking</span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveView('worklist')}
            className={`px-3 py-1.5 text-xs font-medium rounded transition-colors ${
              activeView === 'worklist'
                ? 'bg-cyan-400 text-slate-950 font-semibold'
                : 'bg-slate-900 border border-slate-800 text-slate-300 hover:text-white'
            }`}
          >
            Prioritized Worklist ({tasks.filter((t) => t.status !== 'RESOLVED').length})
          </button>
          <button
            onClick={() => setActiveView('ptp')}
            className={`px-3 py-1.5 text-xs font-medium rounded transition-colors ${
              activeView === 'ptp'
                ? 'bg-cyan-400 text-slate-950 font-semibold'
                : 'bg-slate-900 border border-slate-800 text-slate-300 hover:text-white'
            }`}
          >
            Promise-to-Pay Monitor ({ptpTasks.length})
          </button>
          <button
            onClick={() => setActiveView('customers')}
            className={`px-3 py-1.5 text-xs font-medium rounded transition-colors ${
              activeView === 'customers'
                ? 'bg-cyan-400 text-slate-950 font-semibold'
                : 'bg-slate-900 border border-slate-800 text-slate-300 hover:text-white'
            }`}
          >
            Customer Risk Scoring ({customers.length})
          </button>
        </div>
      </div>

      {/* View 1: Prioritized Collector Worklist */}
      {activeView === 'worklist' && (
        <div className="space-y-4">
          {/* Priority Filter Bar */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5">
              <span className="text-xs text-slate-400 mr-2">Filter Priority:</span>
              <button
                onClick={() => setFilterPriority('ALL')}
                className={`px-2.5 py-1 text-xs rounded transition-colors ${
                  filterPriority === 'ALL'
                    ? 'bg-slate-200 text-slate-950 font-medium'
                    : 'bg-slate-900 text-slate-400 hover:text-white'
                }`}
              >
                All Priorities
              </button>
              <button
                onClick={() => setFilterPriority('HIGH')}
                className={`px-2.5 py-1 text-xs rounded transition-colors ${
                  filterPriority === 'HIGH'
                    ? 'bg-rose-500 text-white font-medium'
                    : 'bg-slate-900 text-slate-400 hover:text-white'
                }`}
              >
                High Urgency
              </button>
              <button
                onClick={() => setFilterPriority('MEDIUM')}
                className={`px-2.5 py-1 text-xs rounded transition-colors ${
                  filterPriority === 'MEDIUM'
                    ? 'bg-amber-500 text-slate-950 font-medium'
                    : 'bg-slate-900 text-slate-400 hover:text-white'
                }`}
              >
                Medium
              </button>
              <button
                onClick={() => setFilterPriority('LOW')}
                className={`px-2.5 py-1 text-xs rounded transition-colors ${
                  filterPriority === 'LOW'
                    ? 'bg-emerald-500 text-slate-950 font-medium'
                    : 'bg-slate-900 text-slate-400 hover:text-white'
                }`}
              >
                Low / Routine
              </button>
            </div>
            <span className="text-xs text-slate-400 font-mono">
              Auto-ranked by default risk & exposure
            </span>
          </div>

          {/* Worklist Cards */}
          <div className="space-y-3">
            {filteredTasks.map((task) => {
              const customer = customers.find((c) => c.id === task.customerId);
              const invoice = invoices.find((inv) => inv.id === task.invoiceId);
              const isResolved = task.status === 'RESOLVED';

              return (
                <div
                  key={task.id}
                  className={`p-4 bg-slate-900/70 border rounded transition-colors ${
                    isResolved
                      ? 'border-slate-800/40 opacity-50'
                      : task.priority === 'HIGH'
                      ? 'border-rose-900/40 hover:border-rose-700/60'
                      : 'border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                    {/* Left: Task Urgency and Reason */}
                    <div className="space-y-1.5 max-w-3xl">
                      <div className="flex items-center gap-2.5">
                        <span
                          className={`text-xs font-mono font-bold px-2 py-0.5 rounded ${
                            task.priority === 'HIGH'
                              ? 'bg-rose-950/80 text-rose-300 border border-rose-800/60'
                              : task.priority === 'MEDIUM'
                              ? 'bg-amber-950/80 text-amber-300 border border-amber-800/60'
                              : 'bg-emerald-950/80 text-emerald-300 border border-emerald-800/60'
                          }`}
                        >
                          {task.priority} PRIORITY
                        </span>
                        <span className="text-sm font-bold text-white">{task.customerName}</span>
                        <span className="text-xs font-mono text-cyan-400">{task.invoiceNumber}</span>
                      </div>

                      <div className="text-xs text-slate-300 font-medium">
                        {task.primaryIssue}
                      </div>

                      <div className="text-xs text-cyan-300/90 flex items-center gap-1.5">
                        <span className="text-slate-400">Action:</span>
                        <span>{task.suggestedAction}</span>
                      </div>

                      <div className="flex items-center gap-2 text-xs text-slate-400 pt-0.5">
                        <span>Balance: {formatCurrency(task.amount)}</span>
                        <span aria-hidden="true">·</span>
                        <span className="text-rose-400">+{task.daysOverdue}d overdue</span>
                        <span aria-hidden="true">·</span>
                        <span>Contact: {customer?.primaryContact.name} ({customer?.primaryContact.phone})</span>
                        {task.hasPtp && (
                          <>
                            <span aria-hidden="true">·</span>
                            <span className={task.ptpStatus === 'BROKEN' ? 'text-rose-400 font-semibold' : 'text-amber-400'}>
                              PTP: {formatCurrency(task.ptpAmount || 0)} committed by {task.ptpDate} ({task.ptpStatus})
                            </span>
                          </>
                        )}
                      </div>
                    </div>

                    {/* Right: Actions */}
                    <div className="flex items-center gap-2 shrink-0">
                      {!isResolved ? (
                        <>
                          <button
                            onClick={() => onOpenPtpModal(task)}
                            className="px-3 py-1.5 text-xs font-medium text-slate-200 bg-slate-800 hover:bg-slate-700 rounded transition-colors whitespace-nowrap"
                          >
                            Log Call / PTP
                          </button>
                          <button
                            onClick={() =>
                              onSendInstantPaymentLink(
                                task.invoiceNumber,
                                customer?.primaryContact.email || 'billing@example.com'
                              )
                            }
                            className="px-3 py-1.5 text-xs font-medium text-cyan-300 bg-cyan-950/60 border border-cyan-800/60 hover:bg-cyan-900/60 rounded transition-colors whitespace-nowrap"
                          >
                            Send Payment Link
                          </button>
                          <button
                            onClick={() => onResolveTask(task.id)}
                            className="px-3 py-1.5 text-xs font-semibold text-slate-950 bg-emerald-400 hover:bg-emerald-300 rounded transition-colors whitespace-nowrap"
                          >
                            Mark Completed
                          </button>
                        </>
                      ) : (
                        <div className="text-xs font-mono text-emerald-400 bg-emerald-950/40 px-2.5 py-1 border border-emerald-800/40 rounded">
                          ✓ Action Completed
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* View 2: Promise-to-Pay (PTP) Monitor */}
      {activeView === 'ptp' && (
        <div className="space-y-4">
          <div className="p-4 bg-slate-900/70 border border-slate-800 rounded">
            <h2 className="text-base font-semibold text-white">Active Promise-to-Pay Commitments</h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Tracks payment promises negotiated by collectors. Automatically correlates against incoming bank feeds.
            </p>
          </div>

          <div className="overflow-x-auto border border-slate-800 rounded bg-slate-900/50">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-slate-950 text-slate-400 uppercase font-mono border-b border-slate-800">
                <tr>
                  <th className="py-2.5 px-4 font-medium">Customer</th>
                  <th className="py-2.5 px-4 font-medium">Invoice Number</th>
                  <th className="py-2.5 px-4 font-medium">Committed Date</th>
                  <th className="py-2.5 px-4 font-medium text-right">Committed Amount</th>
                  <th className="py-2.5 px-4 font-medium text-center">Status</th>
                  <th className="py-2.5 px-4 font-medium text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/80">
                {ptpTasks.map((t) => (
                  <tr key={t.id} className="hover:bg-slate-800/40 transition-colors">
                    <td className="py-3 px-4 font-semibold text-white">{t.customerName}</td>
                    <td className="py-3 px-4 font-mono text-cyan-400">{t.invoiceNumber}</td>
                    <td className="py-3 px-4 font-mono text-slate-300 tabular-nums">{t.ptpDate}</td>
                    <td className="py-3 px-4 text-right font-mono font-bold text-white tabular-nums">
                      {formatCurrency(t.ptpAmount || t.amount)}
                    </td>
                    <td className="py-3 px-4 text-center">
                      <span
                        className={`text-xs font-mono px-2 py-0.5 rounded ${
                          t.ptpStatus === 'BROKEN'
                            ? 'bg-rose-950/80 text-rose-300 border border-rose-800/60'
                            : t.ptpStatus === 'KEPT'
                            ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-800/60'
                            : 'bg-amber-950/80 text-amber-300 border border-amber-800/60'
                        }`}
                      >
                        {t.ptpStatus || 'PENDING'}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right">
                      <button
                        onClick={() => onOpenPtpModal(t)}
                        className="px-2.5 py-1 text-xs text-slate-300 hover:text-white bg-slate-800 rounded"
                      >
                        Update PTP
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* View 3: Customer Accounts Ledger & Risk Matrix */}
      {activeView === 'customers' && (
        <div className="space-y-4">
          <div className="p-4 bg-slate-900/70 border border-slate-800 rounded">
            <h2 className="text-base font-semibold text-white">Customer Risk Ratings & Credit Exposure</h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Continuously calculated from payment timeliness, invoice aging, dispute velocity, and credit utilization.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {customers.map((c) => (
              <div key={c.id} className="p-4 bg-slate-900/70 border border-slate-800 rounded space-y-3">
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="text-sm font-bold text-white">{c.name}</h3>
                    <span className="text-xs text-slate-400">{c.industry}</span>
                  </div>
                  <span
                    className={`text-xs font-mono font-semibold px-2 py-0.5 rounded ${
                      c.riskLevel === 'LOW'
                        ? 'text-emerald-300 bg-emerald-950/80 border border-emerald-800/60'
                        : c.riskLevel === 'MEDIUM'
                        ? 'text-amber-300 bg-amber-950/80 border border-amber-800/60'
                        : 'text-rose-300 bg-rose-950/80 border border-rose-800/60'
                    }`}
                  >
                    {c.riskLevel} RISK
                  </span>
                </div>

                <div className="divide-y divide-slate-800 text-xs">
                  <div className="py-1.5 flex justify-between">
                    <span className="text-slate-400">Total Outstanding AR:</span>
                    <span className="font-mono text-white font-semibold tabular-nums">{formatCurrency(c.totalAR)}</span>
                  </div>
                  <div className="py-1.5 flex justify-between">
                    <span className="text-slate-400">Overdue Balance:</span>
                    <span className="font-mono text-rose-400 font-semibold tabular-nums">{formatCurrency(c.overdueAR)}</span>
                  </div>
                  <div className="py-1.5 flex justify-between">
                    <span className="text-slate-400">Credit Limit:</span>
                    <span className="font-mono text-slate-300 tabular-nums">{formatCurrency(c.creditLimit)}</span>
                  </div>
                  <div className="py-1.5 flex justify-between">
                    <span className="text-slate-400">Customer DSO:</span>
                    <span className="font-mono text-cyan-400 tabular-nums">{c.currentDSO} Days</span>
                  </div>
                  <div className="py-1.5 flex justify-between">
                    <span className="text-slate-400">Payment Velocity Trend:</span>
                    <span className="font-mono text-slate-200">{c.velocityTrend}</span>
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
                  <span>Contact: {c.primaryContact.name}</span>
                  <a
                    href={`mailto:${c.primaryContact.email}`}
                    className="text-cyan-400 hover:text-cyan-300"
                  >
                    Email AP
                  </a>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
