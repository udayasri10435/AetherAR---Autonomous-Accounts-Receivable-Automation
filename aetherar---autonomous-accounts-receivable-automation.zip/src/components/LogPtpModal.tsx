import React, { useState } from 'react';
import { CollectorTask } from '../types';

interface LogPtpModalProps {
  task: CollectorTask | null;
  onClose: () => void;
  onSavePtp: (taskId: string, amount: number, committedDate: string, notes: string) => void;
}

export const LogPtpModal: React.FC<LogPtpModalProps> = ({
  task,
  onClose,
  onSavePtp,
}) => {
  if (!task) return null;

  const [amount, setAmount] = useState<number>(task.ptpAmount || task.amount);
  const [committedDate, setCommittedDate] = useState<string>(
    task.ptpDate ||
      new Date(Date.now() + 5 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
  );
  const [notes, setNotes] = useState<string>(
    'Spoke with AP contact; batch approved for processing on committed date.'
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSavePtp(task.id, Number(amount), committedDate, notes);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
      <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded shadow-2xl overflow-hidden">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800">
          <div>
            <h2 className="text-base font-bold text-white">Log Collector Call & Promise to Pay</h2>
            <p className="text-xs text-slate-400 mt-0.5">{task.customerName} · {task.invoiceNumber}</p>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white text-lg">✕</button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
          <div className="space-y-1">
            <label className="text-slate-300 font-medium">Committed Settlement Amount ($)</label>
            <input
              type="number"
              step="any"
              value={amount}
              onChange={(e) => setAmount(Number(e.target.value))}
              required
              className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded text-white font-mono focus:outline-none focus:border-cyan-500"
            />
          </div>

          <div className="space-y-1">
            <label className="text-slate-300 font-medium">Committed Payment Arrival Date</label>
            <input
              type="date"
              value={committedDate}
              onChange={(e) => setCommittedDate(e.target.value)}
              required
              className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded text-white font-mono focus:outline-none focus:border-cyan-500"
            />
          </div>

          <div className="space-y-1">
            <label className="text-slate-300 font-medium">Collector Conversation Notes</label>
            <textarea
              rows={3}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded text-slate-200 focus:outline-none focus:border-cyan-500"
            />
          </div>

          <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-3 py-1.5 text-xs text-slate-400 hover:text-white"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 text-xs font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded transition-colors"
            >
              Record Commitment
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
