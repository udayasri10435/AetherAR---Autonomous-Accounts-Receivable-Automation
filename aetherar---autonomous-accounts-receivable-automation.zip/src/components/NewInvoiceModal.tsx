import React, { useState } from 'react';
import { Customer, Invoice } from '../types';

interface NewInvoiceModalProps {
  customers: Customer[];
  onClose: () => void;
  onCreateInvoice: (newInv: Partial<Invoice>) => void;
}

export const NewInvoiceModal: React.FC<NewInvoiceModalProps> = ({
  customers,
  onClose,
  onCreateInvoice,
}) => {
  const [customerId, setCustomerId] = useState<string>(customers[0]?.id || '');
  const [invoiceNumber, setInvoiceNumber] = useState<string>(
    `INV-2026-${Math.floor(10000 + Math.random() * 90000)}`
  );
  const [amount, setAmount] = useState<number>(75000);
  const [poNumber, setPoNumber] = useState<string>(
    `PO-${Math.floor(1000 + Math.random() * 9000)}`
  );
  const [paymentTerms, setPaymentTerms] = useState<string>('Net 30');
  const [dueDate, setDueDate] = useState<string>(
    new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
  );

  const selectedCustomer = customers.find((c) => c.id === customerId);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedCustomer) return;

    onCreateInvoice({
      invoiceNumber,
      customerId: selectedCustomer.id,
      customerName: selectedCustomer.name,
      contactPerson: selectedCustomer.primaryContact.name,
      contactEmail: selectedCustomer.primaryContact.email,
      issueDate: new Date().toISOString().split('T')[0],
      dueDate,
      amount: Number(amount),
      balance: Number(amount),
      status: 'CURRENT',
      agingBucket: 'CURRENT',
      daysOverdue: 0,
      poNumber,
      dunningTier: 0,
      dunningStatus: 'READY',
      paymentTerms,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
      <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded shadow-2xl overflow-hidden">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800">
          <div>
            <h2 className="text-base font-bold text-white">Record New Accounts Receivable Invoice</h2>
            <p className="text-xs text-slate-400 mt-0.5">Direct integration to General Ledger</p>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white text-lg">✕</button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
          <div className="space-y-1">
            <label className="text-slate-300 font-medium">Customer Account</label>
            <select
              value={customerId}
              onChange={(e) => setCustomerId(e.target.value)}
              className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded text-white focus:outline-none focus:border-cyan-500"
            >
              {customers.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name} ({c.industry})
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="text-slate-300 font-medium">Invoice Number</label>
              <input
                type="text"
                value={invoiceNumber}
                onChange={(e) => setInvoiceNumber(e.target.value)}
                required
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded text-white font-mono focus:outline-none focus:border-cyan-500"
              />
            </div>

            <div className="space-y-1">
              <label className="text-slate-300 font-medium">Customer PO #</label>
              <input
                type="text"
                value={poNumber}
                onChange={(e) => setPoNumber(e.target.value)}
                required
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded text-white font-mono focus:outline-none focus:border-cyan-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="text-slate-300 font-medium">Invoice Amount ($)</label>
              <input
                type="number"
                step="any"
                value={amount}
                onChange={(e) => setAmount(Number(e.target.value))}
                required
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded text-white font-mono focus:outline-none focus:border-cyan-500"
              />
            </div>

            <div className="space-y-1">
              <label className="text-slate-300 font-medium">Payment Terms</label>
              <select
                value={paymentTerms}
                onChange={(e) => setPaymentTerms(e.target.value)}
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded text-white focus:outline-none focus:border-cyan-500"
              >
                <option value="Net 30">Net 30</option>
                <option value="2/10 Net 30">2/10 Net 30</option>
                <option value="Net 15">Net 15</option>
                <option value="Net 60">Net 60</option>
              </select>
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-slate-300 font-medium">Due Date</label>
            <input
              type="date"
              value={dueDate}
              onChange={(e) => setDueDate(e.target.value)}
              required
              className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded text-white font-mono focus:outline-none focus:border-cyan-500"
            />
          </div>

          <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-3 py-1.5 text-xs text-slate-400 hover:text-white"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 text-xs font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded transition-colors"
            >
              Post Invoice to Ledger
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
