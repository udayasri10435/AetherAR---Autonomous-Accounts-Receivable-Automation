import React, { useState } from 'react';
import { RemittancePayment, Invoice } from '../types';

interface CashApplicationProps {
  remittances: RemittancePayment[];
  invoices: Invoice[];
  onAutoPostRemittance: (remittanceId: string) => void;
  onApplyManualMatch: (
    remittanceId: string,
    invoiceIds: string[],
    deductionAmount: number,
    deductionReason: string
  ) => void;
}

export const CashApplication: React.FC<CashApplicationProps> = ({
  remittances,
  invoices,
  onAutoPostRemittance,
  onApplyManualMatch,
}) => {
  const [selectedRemittanceId, setSelectedRemittanceId] = useState<string>(
    remittances[0]?.id || ''
  );
  const [analyzingWithAI, setAnalyzingWithAI] = useState(false);
  const [aiAnalysisResult, setAiAnalysisResult] = useState<any>(null);

  const selectedRemittance = remittances.find((r) => r.id === selectedRemittanceId) || remittances[0];

  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      maximumFractionDigits: 0,
    }).format(val);
  };

  // Get candidate invoices for this customer
  const customerInvoices = invoices.filter((inv) => {
    if (!selectedRemittance) return false;
    return (
      inv.customerId === selectedRemittance.customerId ||
      inv.customerName.toLowerCase().includes(selectedRemittance.customerName.toLowerCase().split(' ')[0])
    );
  });

  // Calculate sum of suggested invoices
  const suggestedInvoices = invoices.filter((inv) =>
    selectedRemittance?.suggestedInvoiceIds.includes(inv.id)
  );

  const suggestedTotal = suggestedInvoices.reduce((sum, inv) => sum + inv.balance, 0);
  const totalWithDeductions = suggestedTotal - (selectedRemittance?.deductionAmount || 0);
  const isBalanced = Math.abs(totalWithDeductions - (selectedRemittance?.amount || 0)) < 0.01;

  // Call Server Gemini Reconcile API with fallback
  const handleRunAiAnalysis = async () => {
    if (!selectedRemittance) return;
    setAnalyzingWithAI(true);
    setAiAnalysisResult(null);

    try {
      const response = await fetch('/api/gemini/reconcile', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          remittanceData: {
            reference: selectedRemittance.referenceNumber,
            amount: selectedRemittance.amount,
            customer: selectedRemittance.customerName,
            rawText: selectedRemittance.rawRemittanceText,
          },
          candidateInvoices: customerInvoices.map((i) => ({
            id: i.id,
            invoiceNumber: i.invoiceNumber,
            balance: i.balance,
            dueDate: i.dueDate,
            terms: i.paymentTerms,
          })),
        }),
      });

      const data = await response.json();
      if (data.auditSummary) {
        setAiAnalysisResult(data);
      } else {
        // Fallback heuristic explanation
        setAiAnalysisResult({
          confidenceScore: selectedRemittance.confidenceScore,
          matchType: selectedRemittance.deductionAmount > 0 ? 'Discount / Deduction Detected' : 'Exact Multi-Invoice Match',
          deductionAmount: selectedRemittance.deductionAmount,
          deductionReason: selectedRemittance.deductionReason || 'Standard Settlement',
          auditSummary: selectedRemittance.auditTrail,
        });
      }
    } catch (err) {
      console.warn('Using intelligent fallback reconciliation:', err);
      setAiAnalysisResult({
        confidenceScore: selectedRemittance.confidenceScore,
        matchType: selectedRemittance.deductionAmount > 0 ? 'Discount / Deduction Detected' : 'Exact Multi-Invoice Match',
        deductionAmount: selectedRemittance.deductionAmount,
        deductionReason: selectedRemittance.deductionReason || 'Standard Settlement',
        auditSummary: selectedRemittance.auditTrail,
      });
    } finally {
      setAnalyzingWithAI(false);
    }
  };

  const unappliedCount = remittances.filter((r) => r.matchStatus !== 'AUTO_POSTED').length;
  const unappliedAmount = remittances
    .filter((r) => r.matchStatus !== 'AUTO_POSTED')
    .reduce((sum, r) => sum + r.unappliedAmount, 0);

  return (
    <div className="space-y-8 max-w-7xl mx-auto px-4 sm:px-6 py-6">
      {/* Page Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white">AI Cash Application & Remittance Reconciliation</h1>
          <div className="flex items-center gap-2 text-xs text-slate-400 mt-1">
            <span>Automated Bank Remittance Matching</span>
            <span aria-hidden="true">·</span>
            <span>ERP 1-Click Auto-Posting</span>
            <span aria-hidden="true">·</span>
            <span>Deduction & Short-Pay Detection</span>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="text-right">
            <div className="text-xs text-slate-400">Unapplied Cash Balance</div>
            <div className="text-lg font-bold font-mono text-emerald-400 tabular-nums">
              {formatCurrency(unappliedAmount)}
            </div>
          </div>
        </div>
      </div>

      {/* Main Grid: Remittance Queue (Left) & Reconciliation Workbench (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Incoming Remittance Feeds */}
        <div className="lg:col-span-5 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-semibold text-white">Incoming Unapplied Remittances ({unappliedCount})</h2>
            <span className="text-xs text-slate-400 font-mono">Bank Feeds Live</span>
          </div>

          <div className="space-y-3">
            {remittances.map((remit) => {
              const isSelected = remit.id === selectedRemittance?.id;
              const isPosted = remit.matchStatus === 'AUTO_POSTED';

              return (
                <div
                  key={remit.id}
                  onClick={() => {
                    setSelectedRemittanceId(remit.id);
                    setAiAnalysisResult(null);
                  }}
                  className={`p-4 border rounded cursor-pointer transition-all ${
                    isSelected
                      ? 'border-cyan-400 bg-cyan-950/20'
                      : isPosted
                      ? 'border-slate-800/40 bg-slate-950/30 opacity-60'
                      : 'border-slate-800 bg-slate-900/70 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-bold text-white">{remit.customerName}</span>
                        <span className="text-xs font-mono text-slate-400">{remit.paymentMethod}</span>
                      </div>
                      <div className="text-xs font-mono text-slate-400 mt-0.5">
                        {remit.referenceNumber} · {remit.depositDate}
                      </div>
                    </div>

                    <div className="text-right">
                      <div className="text-sm font-bold font-mono text-white tabular-nums">
                        {formatCurrency(remit.amount)}
                      </div>
                      <span
                        className={`text-[10px] font-mono px-1.5 py-0.5 rounded ${
                          isPosted
                            ? 'bg-slate-800 text-slate-400'
                            : remit.confidenceScore >= 95
                            ? 'bg-emerald-950 text-emerald-300 border border-emerald-800/60'
                            : remit.confidenceScore >= 80
                            ? 'bg-cyan-950 text-cyan-300 border border-cyan-800/60'
                            : 'bg-amber-950 text-amber-300 border border-amber-800/60'
                        }`}
                      >
                        {isPosted ? 'POSTED' : `${remit.confidenceScore}% AI Confidence`}
                      </span>
                    </div>
                  </div>

                  <div className="mt-2 text-xs text-slate-400 line-clamp-1">
                    {remit.bankAccount}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column: Interactive Reconciliation Workbench */}
        {selectedRemittance && (
          <div className="lg:col-span-7 space-y-6 p-6 bg-slate-900/70 border border-slate-800 rounded">
            {/* Header of Workbench */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
              <div>
                <span className="text-xs font-mono text-cyan-400 uppercase tracking-wider">
                  Reconciliation Workbench
                </span>
                <h3 className="text-lg font-bold text-white mt-0.5">
                  {selectedRemittance.customerName}
                </h3>
                <div className="text-xs text-slate-400">
                  {selectedRemittance.referenceNumber} · {selectedRemittance.paymentMethod} via {selectedRemittance.bankAccount}
                </div>
              </div>

              <div className="text-right">
                <div className="text-xs text-slate-400">Payment Amount Received</div>
                <div className="text-2xl font-bold font-mono text-emerald-400 tabular-nums">
                  {formatCurrency(selectedRemittance.amount)}
                </div>
              </div>
            </div>

            {/* Electronic Remittance Advice Slip Preview */}
            <div className="p-3 bg-slate-950/80 border border-slate-800 rounded font-mono text-xs text-slate-300 space-y-1">
              <div className="text-[11px] text-slate-500 uppercase tracking-wider flex items-center justify-between">
                <span>Extracted Bank Remittance Advice Data</span>
                <span className="text-emerald-400">Parsed via OCR / EDI</span>
              </div>
              <pre className="whitespace-pre-wrap text-slate-300 text-xs font-mono leading-relaxed pt-1">
                {selectedRemittance.rawRemittanceText}
              </pre>
            </div>

            {/* AI Suggested Invoices Match Table */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300">
                  Matched Open Invoices & Allocation
                </h4>
                <button
                  onClick={handleRunAiAnalysis}
                  disabled={analyzingWithAI}
                  className="px-2.5 py-1 text-xs text-cyan-300 bg-cyan-950/60 border border-cyan-800/60 hover:bg-cyan-900/60 rounded transition-colors"
                >
                  {analyzingWithAI ? 'Gemini AI Analyzing...' : 'Deep AI Reconcile'}
                </button>
              </div>

              <div className="divide-y divide-slate-800 border border-slate-800 rounded bg-slate-950/50">
                {suggestedInvoices.length === 0 ? (
                  <div className="p-4 text-xs text-slate-500">No invoices currently selected for match.</div>
                ) : (
                  suggestedInvoices.map((inv) => (
                    <div key={inv.id} className="p-3 flex items-center justify-between text-xs">
                      <div>
                        <div className="font-mono font-semibold text-white">{inv.invoiceNumber}</div>
                        <div className="text-slate-400">PO: {inv.poNumber} · Due: {inv.dueDate} · Terms: {inv.paymentTerms}</div>
                      </div>
                      <div className="text-right">
                        <div className="font-mono font-bold text-white tabular-nums">
                          {formatCurrency(inv.balance)}
                        </div>
                        <span className="text-[11px] text-emerald-400">Matched to payment</span>
                      </div>
                    </div>
                  ))
                )}

                {/* Deductions Row if applicable */}
                {selectedRemittance.deductionAmount > 0 && (
                  <div className="p-3 bg-amber-950/20 flex items-center justify-between text-xs border-t border-amber-900/40">
                    <div>
                      <div className="font-semibold text-amber-300">
                        Adjustment / Allowed Deduction
                      </div>
                      <div className="text-slate-400">{selectedRemittance.deductionReason}</div>
                    </div>
                    <div className="text-right">
                      <div className="font-mono font-bold text-amber-400 tabular-nums">
                        -{formatCurrency(selectedRemittance.deductionAmount)}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Reconciliation Balance Bar */}
            <div className="p-4 bg-slate-950 border border-slate-800 rounded space-y-2">
              <div className="flex justify-between text-xs">
                <span className="text-slate-400">Gross Invoices Matched:</span>
                <span className="font-mono text-white tabular-nums">{formatCurrency(suggestedTotal)}</span>
              </div>
              {selectedRemittance.deductionAmount > 0 && (
                <div className="flex justify-between text-xs text-amber-400">
                  <span>Less Contractual / Claim Deduction:</span>
                  <span className="font-mono tabular-nums">-{formatCurrency(selectedRemittance.deductionAmount)}</span>
                </div>
              )}
              <div className="flex justify-between text-xs border-t border-slate-800 pt-2 font-semibold">
                <span className="text-slate-300">Net Remittance Settlement:</span>
                <span className="font-mono text-white tabular-nums">{formatCurrency(totalWithDeductions)}</span>
              </div>
              <div className="flex justify-between text-xs font-bold pt-1">
                <span className="text-slate-300">Unapplied Discrepancy Balance:</span>
                <span
                  className={`font-mono tabular-nums ${
                    isBalanced ? 'text-emerald-400' : 'text-rose-400'
                  }`}
                >
                  {isBalanced ? '$0.00 (Perfect Match)' : formatCurrency(Math.abs(totalWithDeductions - selectedRemittance.amount))}
                </span>
              </div>
            </div>

            {/* AI Analysis Card if triggered */}
            {aiAnalysisResult && (
              <div className="p-3.5 bg-cyan-950/30 border border-cyan-800/60 rounded text-xs space-y-2">
                <div className="flex items-center justify-between text-cyan-300 font-semibold">
                  <span>AI Audit Trail Analysis</span>
                  <span className="font-mono">{aiAnalysisResult.confidenceScore}% Confidence</span>
                </div>
                <p className="text-slate-300 leading-relaxed">
                  {aiAnalysisResult.auditSummary}
                </p>
                {aiAnalysisResult.deductionReason && (
                  <div className="text-[11px] text-cyan-200">
                    <span className="font-semibold">Reasoning:</span> {aiAnalysisResult.deductionReason}
                  </div>
                )}
              </div>
            )}

            {/* Action Bar */}
            <div className="flex items-center justify-between pt-2">
              <div className="text-xs text-slate-400">
                ERP Post will immediately update General Ledger & customer DSO.
              </div>

              {selectedRemittance.matchStatus !== 'AUTO_POSTED' ? (
                <button
                  onClick={() => onAutoPostRemittance(selectedRemittance.id)}
                  className="px-5 py-2 text-xs font-semibold text-slate-950 bg-emerald-400 hover:bg-emerald-300 rounded transition-colors shadow-sm"
                >
                  Auto-Post to ERP & Clear Invoices
                </button>
              ) : (
                <div className="text-xs font-mono font-bold text-emerald-400 bg-emerald-950/60 px-3 py-1.5 border border-emerald-800 rounded">
                  ✓ Remittance Successfully Cleared & Posted
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
