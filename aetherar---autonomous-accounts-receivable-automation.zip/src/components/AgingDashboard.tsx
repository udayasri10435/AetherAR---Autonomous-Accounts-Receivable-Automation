import React, { useState, useMemo } from 'react';
import { Invoice, Customer, AgingBucket } from '../types';

interface AgingDashboardProps {
  invoices: Invoice[];
  customers: Customer[];
  onSelectInvoice: (invoice: Invoice) => void;
  onNavigateToTab: (tab: 'aging' | 'dunning' | 'collections' | 'cashapp' | 'roi') => void;
  onOpenInvoiceModal: () => void;
}

export const AgingDashboard: React.FC<AgingDashboardProps> = ({
  invoices,
  customers,
  onSelectInvoice,
  onNavigateToTab,
  onOpenInvoiceModal,
}) => {
  const [selectedBucket, setSelectedBucket] = useState<AgingBucket | 'ALL'>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortField, setSortField] = useState<'balance' | 'daysOverdue' | 'dueDate'>('balance');
  const [sortAsc, setSortAsc] = useState(false);

  // Financial aggregates
  const totalAR = useMemo(() => {
    return invoices.reduce((sum, inv) => sum + (inv.status !== 'PAID' ? inv.balance : 0), 0);
  }, [invoices]);

  const currentAR = useMemo(() => {
    return invoices
      .filter((inv) => inv.agingBucket === 'CURRENT' && inv.status !== 'PAID')
      .reduce((sum, inv) => sum + inv.balance, 0);
  }, [invoices]);

  const overdueAR = useMemo(() => {
    return totalAR - currentAR;
  }, [totalAR, currentAR]);

  // Aging Buckets breakdown
  const bucketBreakdown = useMemo(() => {
    const buckets: Record<
      AgingBucket,
      { amount: number; count: number; label: string; range: string; color: string }
    > = {
      CURRENT: { amount: 0, count: 0, label: 'Current', range: '0–30 Days (Not Due)', color: 'bg-emerald-500' },
      PAST_DUE_1_30: { amount: 0, count: 0, label: '1–30 Days', range: '1–30 Days Overdue', color: 'bg-cyan-500' },
      PAST_DUE_31_60: { amount: 0, count: 0, label: '31–60 Days', range: '31–60 Days Overdue', color: 'bg-amber-500' },
      PAST_DUE_61_90: { amount: 0, count: 0, label: '61–90 Days', range: '61–90 Days Overdue', color: 'bg-orange-500' },
      PAST_DUE_90_PLUS: { amount: 0, count: 0, label: '90+ Days', range: '90+ Days Delinquent', color: 'bg-rose-500' },
    };

    invoices.forEach((inv) => {
      if (inv.status !== 'PAID') {
        buckets[inv.agingBucket].amount += inv.balance;
        buckets[inv.agingBucket].count += 1;
      }
    });

    return Object.entries(buckets).map(([key, data]) => ({
      bucket: key as AgingBucket,
      ...data,
      percentage: totalAR > 0 ? (data.amount / totalAR) * 100 : 0,
    }));
  }, [invoices, totalAR]);

  // DSO and CEI Metrics
  // Real DSO = (Total AR / Total Credit Sales in period) * Days in period
  // Assuming $48,000,000 annual sales => $131,506 daily sales
  // DSO = $3,842,500 / $131,506 = ~29.2 to ~41.2 depending on active open items
  const currentDSO = useMemo(() => {
    const dailyCreditSales = 48000000 / 365;
    return Number((totalAR / dailyCreditSales).toFixed(1));
  }, [totalAR]);

  const targetDSO = 34.0;
  const dsoReduction = 4.8; // Achieved drop since automation inception
  const ceiScore = 86.4; // Collection Effectiveness Index

  // Filtered invoices
  const filteredInvoices = useMemo(() => {
    return invoices
      .filter((inv) => {
        if (selectedBucket !== 'ALL' && inv.agingBucket !== selectedBucket) return false;
        if (searchQuery) {
          const q = searchQuery.toLowerCase();
          return (
            inv.invoiceNumber.toLowerCase().includes(q) ||
            inv.customerName.toLowerCase().includes(q) ||
            inv.poNumber.toLowerCase().includes(q)
          );
        }
        return true;
      })
      .sort((a, b) => {
        let diff = 0;
        if (sortField === 'balance') diff = a.balance - b.balance;
        if (sortField === 'daysOverdue') diff = a.daysOverdue - b.daysOverdue;
        if (sortField === 'dueDate') diff = new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime();
        return sortAsc ? diff : -diff;
      });
  }, [invoices, selectedBucket, searchQuery, sortField, sortAsc]);

  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      maximumFractionDigits: 0,
    }).format(val);
  };

  return (
    <div className="space-y-8 max-w-7xl mx-auto px-4 sm:px-6 py-6">
      {/* Page Header with context & direct CFO summary */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white">Accounts Receivable Aging & Executive Portfolio</h1>
          <div className="flex items-center gap-2 text-xs text-slate-400 mt-1">
            <span>Portfolio Liquidity Analysis</span>
            <span aria-hidden="true">·</span>
            <span>Refreshed 2 mins ago</span>
            <span aria-hidden="true">·</span>
            <span>Accounting Basis: Accrual</span>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => onNavigateToTab('roi')}
            className="px-3.5 py-1.5 text-xs font-medium text-cyan-300 bg-cyan-950/60 border border-cyan-800/80 rounded hover:bg-cyan-900/60 transition-colors whitespace-nowrap"
          >
            Calculate DSO Working Capital ROI →
          </button>
          <button
            onClick={() => onNavigateToTab('cashapp')}
            className="px-3.5 py-1.5 text-xs font-medium text-emerald-300 bg-emerald-950/60 border border-emerald-800/80 rounded hover:bg-emerald-900/60 transition-colors whitespace-nowrap"
          >
            Match Unapplied Remittances
          </button>
        </div>
      </div>

      {/* 4 Top-line Executive KPI Cards (Single Elevation, razor 1px borders) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: Total AR */}
        <div className="p-4 bg-slate-900/70 border border-slate-800 rounded">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400">Total Outstanding AR</span>
            <span className="text-xs font-mono text-emerald-400">Current: {((currentAR / totalAR) * 100).toFixed(0)}%</span>
          </div>
          <div className="text-2xl font-bold font-mono tracking-tight text-white mt-2 tabular-nums">
            {formatCurrency(totalAR)}
          </div>
          <div className="flex items-center gap-2 text-xs text-slate-400 mt-2">
            <span>Current: {formatCurrency(currentAR)}</span>
            <span aria-hidden="true">·</span>
            <span className="text-rose-400">Overdue: {formatCurrency(overdueAR)}</span>
          </div>
        </div>

        {/* Card 2: Real-Time DSO */}
        <div className="p-4 bg-slate-900/70 border border-slate-800 rounded">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400">Days Sales Outstanding (DSO)</span>
            <span className="text-xs font-mono text-cyan-400">Target: {targetDSO}d</span>
          </div>
          <div className="flex items-baseline gap-2 mt-2">
            <div className="text-2xl font-bold font-mono tracking-tight text-white tabular-nums">
              {currentDSO} <span className="text-sm font-normal text-slate-400">Days</span>
            </div>
            <span className="text-xs font-mono text-emerald-400">-{dsoReduction}d QoQ</span>
          </div>
          <div className="flex items-center gap-2 text-xs text-slate-400 mt-2">
            <span>Best Possible: 28.2d</span>
            <span aria-hidden="true">·</span>
            <span>Freed Capital: $631k</span>
          </div>
        </div>

        {/* Card 3: Collection Effectiveness Index (CEI) */}
        <div className="p-4 bg-slate-900/70 border border-slate-800 rounded">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400">Collection Effectiveness (CEI)</span>
            <span className="text-xs font-mono text-emerald-400">Benchmark: &gt;80%</span>
          </div>
          <div className="text-2xl font-bold font-mono tracking-tight text-emerald-400 mt-2 tabular-nums">
            {ceiScore}%
          </div>
          <div className="flex items-center gap-2 text-xs text-slate-400 mt-2">
            <span>High Operational Efficiency</span>
            <span aria-hidden="true">·</span>
            <span>+4.2% vs last month</span>
          </div>
        </div>

        {/* Card 4: 90+ Days Exposure / Bad Debt Risk */}
        <div className="p-4 bg-slate-900/70 border border-slate-800 rounded">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400">90+ Days Critical Overdue</span>
            <span className="text-xs font-mono text-rose-400">Attention Required</span>
          </div>
          <div className="text-2xl font-bold font-mono tracking-tight text-rose-400 mt-2 tabular-nums">
            {formatCurrency(bucketBreakdown.find((b) => b.bucket === 'PAST_DUE_90_PLUS')?.amount || 0)}
          </div>
          <div className="flex items-center gap-2 text-xs text-slate-400 mt-2">
            <span>5.6% Portfolio Concentration</span>
            <span aria-hidden="true">·</span>
            <span>1 Account in Dispute</span>
          </div>
        </div>
      </div>

      {/* AR Aging Breakdown: Interactive Stacked Visual Bar & Bucket Cards */}
      <div className="p-5 bg-slate-900/70 border border-slate-800 rounded space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h2 className="text-base font-semibold text-white">Standard AR Aging Distribution</h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Click any bucket below to filter the underlying invoice ledger and trigger automated actions.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setSelectedBucket('ALL')}
              className={`px-3 py-1 text-xs font-medium rounded transition-colors ${
                selectedBucket === 'ALL'
                  ? 'bg-white text-slate-950 font-semibold'
                  : 'bg-slate-800 text-slate-300 hover:text-white'
              }`}
            >
              Show All Buckets
            </button>
          </div>
        </div>

        {/* Continuous Stacked Visual Bar */}
        <div className="w-full h-3 bg-slate-800 rounded-full overflow-hidden flex">
          {bucketBreakdown.map((item) => (
            <div
              key={item.bucket}
              style={{ width: `${Math.max(item.percentage, 1)}%` }}
              className={`${item.color} h-full transition-all duration-300 cursor-pointer hover:opacity-80`}
              title={`${item.label}: ${formatCurrency(item.amount)} (${item.percentage.toFixed(1)}%)`}
              onClick={() => setSelectedBucket(item.bucket)}
            />
          ))}
        </div>

        {/* Segmented Bucket Summary Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 pt-2">
          {bucketBreakdown.map((item) => {
            const isSelected = selectedBucket === item.bucket;
            return (
              <button
                key={item.bucket}
                onClick={() => setSelectedBucket(isSelected ? 'ALL' : item.bucket)}
                className={`p-3 text-left border rounded transition-all ${
                  isSelected
                    ? 'border-cyan-400 bg-cyan-950/20'
                    : 'border-slate-800 bg-slate-950/40 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-slate-300">{item.label}</span>
                  <span className="text-xs font-mono text-slate-400 tabular-nums">
                    {item.percentage.toFixed(1)}%
                  </span>
                </div>
                <div className="text-lg font-bold font-mono text-white mt-1.5 tabular-nums">
                  {formatCurrency(item.amount)}
                </div>
                <div className="flex items-center gap-1.5 text-xs text-slate-400 mt-1">
                  <span>{item.count} Invoices</span>
                  <span aria-hidden="true">·</span>
                  <span>{item.range}</span>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Two Column Section: Delinquent Concentration Risk + Cash Inflow Velocity */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Top Delinquent Accounts */}
        <div className="lg:col-span-2 p-5 bg-slate-900/70 border border-slate-800 rounded space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-base font-semibold text-white">Top Accounts by Overdue Exposure</h2>
              <p className="text-xs text-slate-400">Prioritized by delinquency age and outstanding volume</p>
            </div>
            <button
              onClick={() => onNavigateToTab('collections')}
              className="text-xs font-medium text-cyan-400 hover:text-cyan-300"
            >
              Open Collections Worklist →
            </button>
          </div>

          <div className="divide-y divide-slate-800/80">
            {customers
              .filter((c) => c.overdueAR > 0)
              .sort((a, b) => b.overdueAR - a.overdueAR)
              .map((c) => (
                <div key={c.id} className="py-3 flex items-center justify-between gap-4">
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-semibold text-white truncate">{c.name}</span>
                      <span className="text-xs text-slate-400">({c.industry})</span>
                    </div>
                    <div className="flex items-center gap-2 text-xs text-slate-400 mt-1">
                      <span>DSO: {c.currentDSO}d</span>
                      <span aria-hidden="true">·</span>
                      <span>Payment Score: {c.paymentScore}/100</span>
                      <span aria-hidden="true">·</span>
                      <span>Risk: {c.riskLevel}</span>
                      {c.activeDisputesCount > 0 && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span className="text-amber-400">{c.activeDisputesCount} Dispute Active</span>
                        </>
                      )}
                    </div>
                  </div>

                  <div className="text-right shrink-0">
                    <div className="text-sm font-bold font-mono text-rose-400 tabular-nums">
                      {formatCurrency(c.overdueAR)}
                    </div>
                    <div className="text-xs text-slate-400 tabular-nums">
                      of {formatCurrency(c.totalAR)} total AR
                    </div>
                  </div>
                </div>
              ))}
          </div>
        </div>

        {/* Expected Cash Inflow Velocity */}
        <div className="p-5 bg-slate-900/70 border border-slate-800 rounded space-y-4">
          <div>
            <h2 className="text-base font-semibold text-white">Projected Cash Inflow</h2>
            <p className="text-xs text-slate-400">Based on historical payment velocity & Dunning cadences</p>
          </div>

          <div className="space-y-4 pt-1">
            <div className="p-3 bg-slate-950/60 border border-slate-800 rounded">
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span>Next 7 Days (Prompt Pay + Maturing)</span>
                <span className="font-mono text-emerald-400">92% Probability</span>
              </div>
              <div className="text-lg font-bold font-mono text-white mt-1 tabular-nums">$695,000</div>
              <div className="w-full h-1.5 bg-slate-800 rounded-full mt-2 overflow-hidden">
                <div className="bg-emerald-500 h-full w-[92%]" />
              </div>
            </div>

            <div className="p-3 bg-slate-950/60 border border-slate-800 rounded">
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span>8–30 Days (Scheduled Billing Batches)</span>
                <span className="font-mono text-cyan-400">84% Probability</span>
              </div>
              <div className="text-lg font-bold font-mono text-white mt-1 tabular-nums">$1,485,000</div>
              <div className="w-full h-1.5 bg-slate-800 rounded-full mt-2 overflow-hidden">
                <div className="bg-cyan-500 h-full w-[84%]" />
              </div>
            </div>

            <div className="p-3 bg-slate-950/60 border border-slate-800 rounded">
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span>31–60 Days (Dunning Collections Recovery)</span>
                <span className="font-mono text-amber-400">68% Probability</span>
              </div>
              <div className="text-lg font-bold font-mono text-white mt-1 tabular-nums">$412,000</div>
              <div className="w-full h-1.5 bg-slate-800 rounded-full mt-2 overflow-hidden">
                <div className="bg-amber-500 h-full w-[68%]" />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Invoice Ledger Table */}
      <div className="p-5 bg-slate-900/70 border border-slate-800 rounded space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-base font-semibold text-white">Active Invoice Ledger</h2>
            <div className="flex items-center gap-2 text-xs text-slate-400 mt-0.5">
              <span>Showing {filteredInvoices.length} invoices</span>
              <span aria-hidden="true">·</span>
              <span>Filter: {selectedBucket === 'ALL' ? 'All Aging Buckets' : selectedBucket}</span>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <input
              type="text"
              placeholder="Search invoice #, customer, PO..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="px-3 py-1.5 text-xs bg-slate-950 border border-slate-800 rounded text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-cyan-500 w-64"
            />
            <button
              onClick={onOpenInvoiceModal}
              className="px-3 py-1.5 text-xs font-medium text-slate-200 bg-slate-800 hover:bg-slate-700 rounded transition-colors whitespace-nowrap"
            >
              + Add Invoice
            </button>
          </div>
        </div>

        {/* Table container with horizontal scroll */}
        <div className="overflow-x-auto border border-slate-800 rounded">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-950 text-slate-400 uppercase font-mono border-b border-slate-800">
              <tr>
                <th className="py-2.5 px-4 font-medium">Invoice Number</th>
                <th className="py-2.5 px-4 font-medium">Customer</th>
                <th className="py-2.5 px-4 font-medium">Due Date</th>
                <th
                  className="py-2.5 px-4 font-medium cursor-pointer hover:text-white"
                  onClick={() => {
                    if (sortField === 'daysOverdue') setSortAsc(!sortAsc);
                    else {
                      setSortField('daysOverdue');
                      setSortAsc(false);
                    }
                  }}
                >
                  Days Overdue {sortField === 'daysOverdue' ? (sortAsc ? '↑' : '↓') : ''}
                </th>
                <th className="py-2.5 px-4 font-medium">Aging Bucket</th>
                <th
                  className="py-2.5 px-4 font-medium text-right cursor-pointer hover:text-white"
                  onClick={() => {
                    if (sortField === 'balance') setSortAsc(!sortAsc);
                    else {
                      setSortField('balance');
                      setSortAsc(false);
                    }
                  }}
                >
                  Balance {sortField === 'balance' ? (sortAsc ? '↑' : '↓') : ''}
                </th>
                <th className="py-2.5 px-4 font-medium text-center">Dunning Tier</th>
                <th className="py-2.5 px-4 font-medium text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80 bg-slate-900/30">
              {filteredInvoices.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-slate-500">
                    No invoices match the specified criteria.
                  </td>
                </tr>
              ) : (
                filteredInvoices.map((inv) => (
                  <tr
                    key={inv.id}
                    className="hover:bg-slate-800/50 transition-colors cursor-pointer"
                    onClick={() => onSelectInvoice(inv)}
                  >
                    <td className="py-3 px-4 font-mono font-medium text-white">
                      {inv.invoiceNumber}
                      <div className="text-[11px] text-slate-500 font-mono">{inv.poNumber}</div>
                    </td>
                    <td className="py-3 px-4 font-medium text-slate-200">
                      {inv.customerName}
                      <div className="text-[11px] text-slate-500">{inv.contactPerson}</div>
                    </td>
                    <td className="py-3 px-4 font-mono text-slate-300 tabular-nums">
                      {inv.dueDate}
                      <div className="text-[11px] text-slate-500">{inv.paymentTerms}</div>
                    </td>
                    <td className="py-3 px-4 font-mono tabular-nums">
                      {inv.daysOverdue > 0 ? (
                        <span className={inv.daysOverdue > 60 ? 'text-rose-400 font-bold' : inv.daysOverdue > 30 ? 'text-amber-400' : 'text-cyan-400'}>
                          +{inv.daysOverdue} days
                        </span>
                      ) : (
                        <span className="text-emerald-400">Current</span>
                      )}
                    </td>
                    <td className="py-3 px-4">
                      <span className="text-xs text-slate-300">
                        {inv.agingBucket === 'CURRENT' && 'Current (0–30)'}
                        {inv.agingBucket === 'PAST_DUE_1_30' && '1–30 Days'}
                        {inv.agingBucket === 'PAST_DUE_31_60' && '31–60 Days'}
                        {inv.agingBucket === 'PAST_DUE_61_90' && '61–90 Days'}
                        {inv.agingBucket === 'PAST_DUE_90_PLUS' && '90+ Days Critical'}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right font-mono font-semibold text-white tabular-nums">
                      {formatCurrency(inv.balance)}
                    </td>
                    <td className="py-3 px-4 text-center">
                      <span className="text-xs font-mono text-slate-300">
                        Tier {inv.dunningTier}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right" onClick={(e) => e.stopPropagation()}>
                      <button
                        onClick={() => onSelectInvoice(inv)}
                        className="px-2.5 py-1 text-xs text-cyan-400 hover:text-cyan-300 bg-cyan-950/40 border border-cyan-800/60 rounded"
                      >
                        Inspect
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
