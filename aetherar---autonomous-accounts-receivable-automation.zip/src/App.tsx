/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { TopBar } from './components/TopBar';
import { AgingDashboard } from './components/AgingDashboard';
import { AutoDunning } from './components/AutoDunning';
import { SmartCollections } from './components/SmartCollections';
import { CashApplication } from './components/CashApplication';
import { RoiCalculator } from './components/RoiCalculator';
import { InvoiceDetailModal } from './components/InvoiceDetailModal';
import { DunningEmailModal } from './components/DunningEmailModal';
import { LogPtpModal } from './components/LogPtpModal';
import { NewInvoiceModal } from './components/NewInvoiceModal';

import {
  INITIAL_CUSTOMERS,
  INITIAL_INVOICES,
  INITIAL_DUNNING_TIERS,
  INITIAL_DUNNING_QUEUE,
  INITIAL_REMITTANCES,
  INITIAL_COLLECTOR_TASKS,
} from './data/mockData';
import { Customer, Invoice, RemittancePayment, CollectorTask, DunningTierConfig, DunningQueueItem } from './types';

export default function App() {
  const [activeTab, setActiveTab] = useState<'aging' | 'dunning' | 'collections' | 'cashapp' | 'roi'>('aging');

  // Application State
  const [customers, setCustomers] = useState<Customer[]>(INITIAL_CUSTOMERS);
  const [invoices, setInvoices] = useState<Invoice[]>(INITIAL_INVOICES);
  const [dunningTiers, setDunningTiers] = useState<DunningTierConfig[]>(INITIAL_DUNNING_TIERS);
  const [dunningQueue, setDunningQueue] = useState<DunningQueueItem[]>(INITIAL_DUNNING_QUEUE);
  const [remittances, setRemittances] = useState<RemittancePayment[]>(INITIAL_REMITTANCES);
  const [collectorTasks, setCollectorTasks] = useState<CollectorTask[]>(INITIAL_COLLECTOR_TASKS);

  // UI & Modals State
  const [selectedInvoice, setSelectedInvoice] = useState<Invoice | null>(null);
  const [selectedDunningItem, setSelectedDunningItem] = useState<DunningQueueItem | null>(null);
  const [selectedTaskForPtp, setSelectedTaskForPtp] = useState<CollectorTask | null>(null);
  const [isNewInvoiceModalOpen, setIsNewInvoiceModalOpen] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((prev) => (prev === msg ? null : prev));
    }, 3500);
  };

  // 1. Dunning Actions
  const handleDispatchQueueItem = (itemId: string) => {
    setDunningQueue((prev) =>
      prev.map((item) =>
        item.id === itemId ? { ...item, status: 'SENT' } : item
      )
    );
    showToast('Dunning communication dispatched to customer AP.');
  };

  const handleDispatchAllDunning = () => {
    setDunningQueue((prev) =>
      prev.map((item) => ({ ...item, status: 'SENT' }))
    );
    showToast(`Successfully dispatched scheduled dunning communications.`);
  };

  const handlePauseDunningItem = (itemId: string) => {
    setDunningQueue((prev) =>
      prev.map((item) =>
        item.id === itemId ? { ...item, status: 'PAUSED' } : item
      )
    );
    showToast('Dunning action placed on temporary hold.');
  };

  const handleSendCustomDunning = (itemId: string, subject: string, body: string) => {
    setDunningQueue((prev) =>
      prev.map((item) =>
        item.id === itemId
          ? { ...item, status: 'SENT', generatedSubject: subject, generatedBody: body }
          : item
      )
    );
    showToast('Personalized communication dispatched with electronic payment link.');
  };

  const handleToggleTierAutoSend = (tierNumber: number) => {
    setDunningTiers((prev) =>
      prev.map((tier) =>
        tier.tier === tierNumber ? { ...tier, autoSend: !tier.autoSend } : tier
      )
    );
    showToast(`Updated auto-send policy for Tier ${tierNumber}.`);
  };

  // 2. Cash Application Actions
  const handleAutoPostRemittance = (remittanceId: string) => {
    const remit = remittances.find((r) => r.id === remittanceId);
    if (!remit) return;

    // Apply against invoices
    setInvoices((prev) =>
      prev.map((inv) => {
        if (remit.suggestedInvoiceIds.includes(inv.id)) {
          return {
            ...inv,
            balance: 0,
            status: 'PAID',
            agingBucket: 'CURRENT',
            daysOverdue: 0,
          };
        }
        return inv;
      })
    );

    // Update customer AR balance
    if (remit.customerId) {
      setCustomers((prev) =>
        prev.map((c) =>
          c.id === remit.customerId
            ? {
                ...c,
                totalAR: Math.max(0, c.totalAR - remit.amount),
                overdueAR: Math.max(0, c.overdueAR - remit.amount),
                currentDSO: Math.max(22, Number((c.currentDSO - 4.2).toFixed(1))),
              }
            : c
        )
      );
    }

    // Mark remittance as posted
    setRemittances((prev) =>
      prev.map((r) =>
        r.id === remittanceId
          ? {
              ...r,
              matchStatus: 'AUTO_POSTED',
              appliedAmount: r.amount,
              unappliedAmount: 0,
            }
          : r
      )
    );

    // Also resolve associated collector task if present
    setCollectorTasks((prev) =>
      prev.map((t) =>
        remit.suggestedInvoiceIds.includes(t.invoiceId)
          ? { ...t, status: 'RESOLVED' }
          : t
      )
    );

    showToast(`Auto-posted ${remit.referenceNumber} ($${remit.amount.toLocaleString()}) to ERP General Ledger!`);
  };

  const handleApplyManualMatch = (
    remittanceId: string,
    invoiceIds: string[],
    deductionAmount: number,
    deductionReason: string
  ) => {
    setRemittances((prev) =>
      prev.map((r) =>
        r.id === remittanceId
          ? {
              ...r,
              suggestedInvoiceIds: invoiceIds,
              deductionAmount,
              deductionReason,
            }
          : r
      )
    );
    showToast('Manual match allocation updated.');
  };

  // 3. Smart Collections Actions
  const handleResolveTask = (taskId: string) => {
    setCollectorTasks((prev) =>
      prev.map((t) => (t.id === taskId ? { ...t, status: 'RESOLVED' } : t))
    );
    showToast('Collector action marked as completed.');
  };

  const handleSavePtp = (
    taskId: string,
    amount: number,
    committedDate: string,
    notes: string
  ) => {
    const task = collectorTasks.find((t) => t.id === taskId);
    if (!task) return;

    setCollectorTasks((prev) =>
      prev.map((t) =>
        t.id === taskId
          ? {
              ...t,
              hasPtp: true,
              ptpAmount: amount,
              ptpDate: committedDate,
              ptpStatus: 'PENDING',
              suggestedAction: `Follow up on PTP of $${amount.toLocaleString()} due by ${committedDate}.`,
            }
          : t
      )
    );

    // Update invoice record
    setInvoices((prev) =>
      prev.map((inv) =>
        inv.id === task.invoiceId
          ? {
              ...inv,
              promiseToPayAmount: amount,
              promiseToPayDate: committedDate,
            }
          : inv
      )
    );

    showToast(`Promise to Pay of $${amount.toLocaleString()} recorded for ${committedDate}.`);
  };

  const handleSendInstantPaymentLink = (invoiceNumber: string, email: string) => {
    showToast(`Self-serve payment link sent to ${email} for invoice ${invoiceNumber}.`);
  };

  // 4. Invoices Management
  const handleCreateInvoice = (newInv: Partial<Invoice>) => {
    const fullInvoice: Invoice = {
      id: `INV-${Math.floor(10000 + Math.random() * 90000)}`,
      invoiceNumber: newInv.invoiceNumber || 'INV-2026-99999',
      customerId: newInv.customerId || 'CUST-001',
      customerName: newInv.customerName || 'Customer Corp',
      contactPerson: newInv.contactPerson || 'AP Department',
      contactEmail: newInv.contactEmail || 'ap@example.com',
      issueDate: newInv.issueDate || new Date().toISOString().split('T')[0],
      dueDate: newInv.dueDate || new Date().toISOString().split('T')[0],
      amount: newInv.amount || 50000,
      balance: newInv.balance || 50000,
      status: newInv.status || 'CURRENT',
      agingBucket: newInv.agingBucket || 'CURRENT',
      daysOverdue: 0,
      poNumber: newInv.poNumber || 'PO-AUTO',
      dunningTier: 0,
      dunningStatus: 'READY',
      paymentTerms: newInv.paymentTerms || 'Net 30',
    };

    setInvoices((prev) => [fullInvoice, ...prev]);

    // Update customer total AR
    setCustomers((prev) =>
      prev.map((c) =>
        c.id === fullInvoice.customerId
          ? { ...c, totalAR: c.totalAR + fullInvoice.amount }
          : c
      )
    );

    showToast(`Invoice ${fullInvoice.invoiceNumber} ($${fullInvoice.amount.toLocaleString()}) recorded.`);
  };

  const handleMarkInvoicePaid = (invoiceId: string) => {
    setInvoices((prev) =>
      prev.map((inv) =>
        inv.id === invoiceId
          ? {
              ...inv,
              balance: 0,
              status: 'PAID',
              agingBucket: 'CURRENT',
              daysOverdue: 0,
            }
          : inv
      )
    );
    setSelectedInvoice(null);
    showToast('Invoice marked as fully settled.');
  };

  const handleLogDispute = (invoiceId: string, reason: string) => {
    setInvoices((prev) =>
      prev.map((inv) =>
        inv.id === invoiceId
          ? {
              ...inv,
              status: 'DISPUTED',
              disputeReason: reason,
              dunningStatus: 'PAUSED_DISPUTE',
            }
          : inv
      )
    );
    showToast('Billing dispute logged; automated dunning paused for this invoice.');
  };

  // ERP Quick Sync Simulation
  const handleTriggerQuickSync = () => {
    setIsSyncing(true);
    setTimeout(() => {
      setIsSyncing(false);
      showToast('ERP Live Sync complete: 0 bank feed anomalies detected.');
    }, 1200);
  };

  const unappliedCount = remittances.filter((r) => r.matchStatus !== 'AUTO_POSTED').length;
  const dunningQueuePendingCount = dunningQueue.filter((i) => i.status === 'PENDING_DISPATCH').length;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      {/* 3-Zone Top Navigation Contract */}
      <TopBar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenNewInvoiceModal={() => setIsNewInvoiceModalOpen(true)}
        onTriggerQuickSync={handleTriggerQuickSync}
        isSyncing={isSyncing}
        unappliedCount={unappliedCount}
        dunningQueueCount={dunningQueuePendingCount}
      />

      {/* Main Content Viewport */}
      <main className="flex-1 pb-16">
        {activeTab === 'aging' && (
          <AgingDashboard
            invoices={invoices}
            customers={customers}
            onSelectInvoice={(inv) => setSelectedInvoice(inv)}
            onNavigateToTab={(tab) => setActiveTab(tab)}
            onOpenInvoiceModal={() => setIsNewInvoiceModalOpen(true)}
          />
        )}

        {activeTab === 'dunning' && (
          <AutoDunning
            dunningTiers={dunningTiers}
            queueItems={dunningQueue}
            invoices={invoices}
            onDispatchQueueItem={handleDispatchQueueItem}
            onDispatchAll={handleDispatchAllDunning}
            onOpenDraftModal={(item) => setSelectedDunningItem(item)}
            onToggleTierAutoSend={handleToggleTierAutoSend}
            onPauseItem={handlePauseDunningItem}
          />
        )}

        {activeTab === 'collections' && (
          <SmartCollections
            tasks={collectorTasks}
            customers={customers}
            invoices={invoices}
            onResolveTask={handleResolveTask}
            onOpenPtpModal={(task) => setSelectedTaskForPtp(task)}
            onSendInstantPaymentLink={handleSendInstantPaymentLink}
          />
        )}

        {activeTab === 'cashapp' && (
          <CashApplication
            remittances={remittances}
            invoices={invoices}
            onAutoPostRemittance={handleAutoPostRemittance}
            onApplyManualMatch={handleApplyManualMatch}
          />
        )}

        {activeTab === 'roi' && <RoiCalculator />}
      </main>

      {/* Modals */}
      <InvoiceDetailModal
        invoice={selectedInvoice}
        onClose={() => setSelectedInvoice(null)}
        onMarkPaid={handleMarkInvoicePaid}
        onTriggerDunning={(inv) => {
          const queueItem = dunningQueue.find((q) => q.invoiceId === inv.id);
          if (queueItem) {
            setSelectedDunningItem(queueItem);
          } else {
            // Create ad-hoc queue item
            setSelectedDunningItem({
              id: `DN-ADHOC-${inv.id}`,
              invoiceId: inv.id,
              invoiceNumber: inv.invoiceNumber,
              customerId: inv.customerId,
              customerName: inv.customerName,
              contactPerson: inv.contactPerson,
              contactEmail: inv.contactEmail,
              amount: inv.balance,
              daysOverdue: inv.daysOverdue,
              tier: inv.dunningTier,
              tierName: `Tier ${inv.dunningTier} Notice`,
              channel: 'Email',
              status: 'PENDING_DISPATCH',
              generatedSubject: `Payment Notice: Invoice ${inv.invoiceNumber} ($${inv.balance.toLocaleString()})`,
              generatedBody: `Dear ${inv.contactPerson},\n\nWe wanted to follow up regarding invoice ${inv.invoiceNumber} for $${inv.balance.toLocaleString()}.\n\nDirect settlement portal: https://pay.aetherar.internal/inv/${inv.invoiceNumber}\n\nWarm regards,\nAetherAR Billing Operations`,
              aiSuggestedTone: 'Structured Enterprise',
              scheduledTime: 'Immediate',
            });
          }
        }}
        onLogDispute={handleLogDispute}
      />

      <DunningEmailModal
        item={selectedDunningItem}
        onClose={() => setSelectedDunningItem(null)}
        onSend={handleSendCustomDunning}
      />

      <LogPtpModal
        task={selectedTaskForPtp}
        onClose={() => setSelectedTaskForPtp(null)}
        onSavePtp={handleSavePtp}
      />

      {isNewInvoiceModalOpen && (
        <NewInvoiceModal
          customers={customers}
          onClose={() => setIsNewInvoiceModalOpen(false)}
          onCreateInvoice={handleCreateInvoice}
        />
      )}

      {/* Floating System Toast */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 flex items-center gap-2 px-4 py-2.5 bg-slate-900 border border-cyan-800/80 rounded shadow-xl text-xs text-white">
          <span className="w-2 h-2 rounded-full bg-cyan-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Quiet Footer */}
      <footer className="border-t border-slate-900/80 px-6 py-4 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-2">
        <div className="flex items-center gap-2">
          <span className="font-semibold text-slate-400">AetherAR Enterprise</span>
          <span aria-hidden="true">·</span>
          <span>Autonomous Accounts Receivable & Cash Flow Platform</span>
        </div>
        <div className="flex items-center gap-3">
          <span>Enterprise GL Connectors: NetSuite · SAP · Workday</span>
        </div>
      </footer>
    </div>
  );
}
