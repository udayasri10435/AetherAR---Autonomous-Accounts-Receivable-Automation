export type AgingBucket = 'CURRENT' | 'PAST_DUE_1_30' | 'PAST_DUE_31_60' | 'PAST_DUE_61_90' | 'PAST_DUE_90_PLUS';

export type InvoiceStatus = 'CURRENT' | 'OVERDUE' | 'PAID' | 'DISPUTED' | 'PARTIALLY_PAID';

export type RiskLevel = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';

export type VelocityTrend = 'ACCELERATING' | 'STABLE' | 'DRIFTING' | 'CRITICAL';

export interface Invoice {
  id: string;
  invoiceNumber: string;
  customerId: string;
  customerName: string;
  contactPerson: string;
  contactEmail: string;
  issueDate: string;
  dueDate: string;
  amount: number;
  balance: number;
  status: InvoiceStatus;
  agingBucket: AgingBucket;
  daysOverdue: number;
  poNumber: string;
  dunningTier: number; // 0 to 4
  dunningStatus: 'READY' | 'SENT' | 'PAUSED_DISPUTE' | 'COMPLETED';
  disputeReason?: string;
  lastContactDate?: string;
  promiseToPayDate?: string;
  promiseToPayAmount?: number;
  paymentTerms: string; // e.g. "Net 30", "2/10 Net 30"
}

export interface Customer {
  id: string;
  name: string;
  industry: string;
  creditLimit: number;
  totalAR: number;
  overdueAR: number;
  currentDSO: number;
  riskLevel: RiskLevel;
  velocityTrend: VelocityTrend;
  dunningPaused: boolean;
  activeDisputesCount: number;
  paymentScore: number; // 0 - 100
  primaryContact: {
    name: string;
    email: string;
    phone: string;
    title: string;
  };
}

export interface DunningTierConfig {
  tier: number;
  name: string;
  triggerDays: number; // e.g., -7, 1, 15, 30, 60
  channel: 'Email' | 'Email + Controller CC' | 'Executive Escalation' | 'Credit Hold Warning';
  description: string;
  defaultTone: 'Diplomatic' | 'Structured Enterprise' | 'Firm Collections' | 'Executive Notice';
  autoSend: boolean;
  activeInvoiceCount: number;
  totalVolume: number;
}

export interface DunningQueueItem {
  id: string;
  invoiceId: string;
  invoiceNumber: string;
  customerId: string;
  customerName: string;
  contactPerson: string;
  contactEmail: string;
  amount: number;
  daysOverdue: number;
  tier: number;
  tierName: string;
  channel: string;
  status: 'PENDING_DISPATCH' | 'SENT' | 'PAUSED' | 'DISPUTED';
  generatedSubject: string;
  generatedBody: string;
  aiSuggestedTone: string;
  keyTacticalAdvice?: string;
  scheduledTime: string;
}

export interface RemittancePayment {
  id: string;
  referenceNumber: string;
  depositDate: string;
  amount: number;
  appliedAmount: number;
  unappliedAmount: number;
  customerName: string;
  customerId?: string;
  paymentMethod: 'Fedwire' | 'ACH' | 'SWIFT' | 'Lockbox Check';
  bankAccount: string;
  rawRemittanceText: string;
  matchStatus: 'UNMATCHED' | 'AI_SUGGESTED' | 'AUTO_POSTED' | 'DISCREPANCY';
  confidenceScore: number; // 0 - 100
  suggestedInvoiceIds: string[];
  deductionAmount: number;
  deductionReason?: string;
  auditTrail: string;
}

export interface CollectorTask {
  id: string;
  priority: 'HIGH' | 'MEDIUM' | 'LOW';
  customerName: string;
  customerId: string;
  invoiceId: string;
  invoiceNumber: string;
  amount: number;
  daysOverdue: number;
  riskLevel: RiskLevel;
  primaryIssue: string;
  suggestedAction: string;
  status: 'TODO' | 'IN_PROGRESS' | 'RESOLVED';
  hasPtp: boolean;
  ptpDate?: string;
  ptpAmount?: number;
  ptpStatus?: 'PENDING' | 'KEPT' | 'BROKEN';
}

export interface AgingSummary {
  bucket: AgingBucket;
  label: string;
  rangeDays: string;
  amount: number;
  percentage: number;
  invoiceCount: number;
  colorHex: string;
}

export interface RoiSimulationParams {
  annualRevenue: number;
  currentDSO: number;
  targetDSO: number;
  costOfCapitalRate: number; // e.g. 0.085 for 8.5%
  operatingMarginRate: number;
  badDebtReductionRate: number; // estimated % reduction in bad debt write-offs
}
