import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json());

// Initialize Gemini SDK with telemetry header
const geminiApiKey = process.env.GEMINI_API_KEY || '';
const ai = new GoogleGenAI({
  apiKey: geminiApiKey,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// Endpoint: AI-Powered Dunning Communication Drafting
app.post('/api/gemini/dunning', async (req, res) => {
  try {
    const {
      customerName,
      contactPerson,
      invoiceNumber,
      amount,
      daysOverdue,
      tier,
      tierName,
      tone,
      disputeHistory,
      pastPaymentHabits,
    } = req.body;

    if (!geminiApiKey) {
      return res.status(200).json({
        fallback: true,
        message: 'No GEMINI_API_KEY configured on server; using intelligent local dunning engine.',
      });
    }

    const prompt = `You are an elite Enterprise Credit & Collections Specialist at AetherAR.
Write an authentic, highly effective accounts receivable dunning communication.

Parameters:
- Customer Name: ${customerName}
- Contact Person: ${contactPerson}
- Invoice Number: ${invoiceNumber}
- Overdue Amount: $${amount}
- Days Past Due: ${daysOverdue} days
- Dunning Stage: ${tierName} (Tier ${tier})
- Requested Tone: ${tone} (e.g. Diplomatic Concierge, Structured Enterprise, Firm Overdue Notice, Executive Escalation)
- Historical Payment Profile: ${pastPaymentHabits}
- Dispute Status/History: ${disputeHistory || 'None'}

Requirements:
1. Professional, clear, and actionable.
2. Must cite the specific invoice ${invoiceNumber} and amount $${amount}.
3. State payment terms, reference the secure direct payment link [Portal Pay Link: https://pay.aetherar.internal/inv/${invoiceNumber}], and provide wire/ACH routing instructions.
4. Maintain vendor relationship while establishing clear commitment dates.
5. Return JSON with format:
{
  "subject": "Email Subject Line",
  "body": "Formatted email body with greeting, clear request, payment options, and sign-off",
  "keyAdvice": "1-sentence tactical advice for the collector"
}`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const text = response.text || '';
    const parsed = JSON.parse(text);
    return res.json({ success: true, ...parsed });
  } catch (error: any) {
    console.error('Gemini Dunning API Error:', error?.message);
    return res.status(200).json({
      fallback: true,
      error: error?.message,
    });
  }
});

// Endpoint: AI Remittance Advice Reconciliation Matcher
app.post('/api/gemini/reconcile', async (req, res) => {
  try {
    const { remittanceData, candidateInvoices } = req.body;

    if (!geminiApiKey) {
      return res.status(200).json({
        fallback: true,
        message: 'No GEMINI_API_KEY configured; using heuristic matching.',
      });
    }

    const prompt = `You are an AI Cash Application and Reconciliation Specialist for corporate Treasury & Accounts Receivable.
Analyze the following unapplied remittance payment against open customer invoices to identify the optimal matching split, discounts, or short-pay deduction reasons.

Remittance Payment:
${JSON.stringify(remittanceData, null, 2)}

Candidate Open Invoices:
${JSON.stringify(candidateInvoices, null, 2)}

Analyze:
1. Amount match (exact, multi-invoice bundle, early pay discount like 2% 10-net-30, or unearned discount).
2. PO reference or Invoice # match (fuzzy check).
3. Deduction explanation (e.g. freight allowance, damaged goods deduction, tax dispute).

Respond with JSON:
{
  "matchedInvoiceIds": ["string array of matched invoice IDs"],
  "confidenceScore": number between 0 and 100,
  "matchType": "Exact Match" | "Multi-Invoice Bundle" | "Discount Applied" | "Short Pay / Discrepancy",
  "deductionAmount": number,
  "deductionReason": "string description or None",
  "auditSummary": "Clear 2-sentence rationale explaining the AI matching logic for the ERP audit trail"
}`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const text = response.text || '';
    const parsed = JSON.parse(text);
    return res.json({ success: true, ...parsed });
  } catch (error: any) {
    console.error('Gemini Reconcile API Error:', error?.message);
    return res.status(200).json({
      fallback: true,
      error: error?.message,
    });
  }
});

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    geminiConfigured: !!geminiApiKey,
  });
});

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(port, '0.0.0.0', () => {
    console.log(`AetherAR server running on http://0.0.0.0:${port}`);
  });
}

startServer();
